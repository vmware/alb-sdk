<h3 class='text-primary'> Metrics Query Options </h3>
<div class='container-fluid'>
<table class='table table-bordered table-striped'>
<tr>
<th>Option</th>
<th>Description</th>
<th>Defaults</th>
</tr>
<tr>
<td> metric_entity </td>
<td> Describes the entity type for which metrics is requested. Eg. &metric_entity=VSERVER_METRICS_ENTITY </td>
<td> 1 </td>
</tr>
<tr>
<td> entity </td>
<td> UUID of the entity. Eg. entity_uuid=virtualservice-0-1 </td>
<td>  </td>
</tr>
<tr>
<td> serviceengine </td>
<td> UUID of the service engine.Eg. serviceengine_uuid=se-422ce810-50a4-2ecd-d45d-870656e99b7b </td>
<td>  </td>
</tr>
<tr>
<td> metric_id </td>
<td> Comma separated list of metrics requested.Eg. metric_id=l4_client.avg_bandwidth,l7_client.avg_total_responses </td>
<td>  </td>
</tr>
<tr>
<td> start </td>
<td> Start time for the metrics in ISO 8601 format. Default is UNIX Epoch. Eg. start=1970-01-01T00:00:00 </td>
<td> 1970-01-01T00:00:00 </td>
</tr>
<tr>
<td> stop </td>
<td> End time for the metrics in ISO 8601 format. Default is now. Eg. stop=2014-01-01T12:42:42 </td>
<td>  </td>
</tr>
<tr>
<td> limit </td>
<td> Max number of metric samples per metric requestedEg. limit=100 implies return only 100 samples </td>
<td> 60 </td>
</tr>
<tr>
<td> step </td>
<td> Metrics time series returned with time points every time duration specified as step. Eg. if bandwidth is desired every 5 Secs then use step=5&metric_id=l4_client.avg_bandwidth </td>
<td> 5 </td>
</tr>
<tr>
<td> filters </td>
<td> Filters on the metrics. Not supported </td>
<td>  </td>
</tr>
<tr>
<td> order_by </td>
<td> Order metrics series by metric timestamp. -metric_timestamp will result in most recent value first in the time series </td>
<td> metric_timestamp </td>
</tr>
<tr>
<td> include_statistics </td>
<td> Include metrics statistics with the request </td>
<td> True </td>
</tr>
<tr>
<td> pool </td>
<td> metrics for a member pool in a virtual service </td>
<td>  </td>
</tr>
<tr>
<td> obj_id </td>
<td> serverip:port of the pool server </td>
<td>  </td>
</tr>
<tr>
<td> pad_missing_data </td>
<td> Pad missing data when not available </td>
<td> True </td>
</tr>
<tr>
<td> include_refs </td>
<td> Resolve UUID to names </td>
<td> False </td>
</tr>
<tr>
<td> browser </td>
<td> Browser filter. Eg. browser=Chrome </td>
<td>  </td>
</tr>
<tr>
<td> ipgroup </td>
<td> IPGROUP filter Eg. UUID of the IP group </td>
<td>  </td>
</tr>
<tr>
<td> devtype </td>
<td> Device type filter. Eg. devtype=desktop </td>
<td>  </td>
</tr>
<tr>
<td> os </td>
<td> Operating system filter. Eg. os=mac </td>
<td>  </td>
</tr>
<tr>
<td> lang </td>
<td> Language filter. Eg. lang=english </td>
<td>  </td>
</tr>
<tr>
<td> url </td>
<td> URL filter. Eg. url=http://www.avinetworks.com </td>
<td>  </td>
</tr>
<tr>
<td> country </td>
<td> Two letter country filter. Eg. country=US </td>
<td>  </td>
</tr>
<tr>
<td> asn </td>
<td> Autonomous System number. Eg. asn=3794 </td>
<td>  </td>
</tr>
<tr>
<td> dimensions </td>
<td> Group by dimensions for the metrics. Eg. For results by single dimension use dimensions=browser. For results by browser and operating system use dimensions=browser,os </td>
<td>  </td>
</tr>
<tr>
<td> dimension_aggregation </td>
<td> Aggregations for dimensions. Eg. use dimenstion_aggregation=avg for averaged metric values </td>
<td> 0 </td>
</tr>
<tr>
<td> server </td>
<td> Pool Server ID in format server IP:port. Eg. 10.10.1.42:80 </td>
<td>  </td>
</tr>
<tr>
<td> dimension_filter_op </td>
<td> Filters the obj_id based on the filter specified. </td>
<td> 1 </td>
</tr>
<tr>
<td> validate_data </td>
<td> Validate every data before returning. This will result in increased latency and should only be used for troubleshooting </td>
<td> False </td>
</tr>
<tr>
<td> dimension_limit </td>
<td> Limit the number of dimensions in the result. specially useful in case of URLs </td>
<td> 10 </td>
</tr>
<tr>
<td> client_insights </td>
<td> Client Insights Source Type - Active or Passive </td>
<td> 3 </td>
</tr>
<tr>
<td> detailed_header </td>
<td> Detailed header returns metric information, statistics etc. It is has overhead which can be bypassed if caller just wants raw data </td>
<td> True </td>
</tr>
<tr>
<td> tenant </td>
<td> UUID of the Tenant.  </td>
<td>  </td>
</tr>
<tr>
<td> attack </td>
<td> Dos Attack ID filter </td>
<td>  </td>
</tr>
<tr>
<td> aggregate_entity </td>
<td> Required if the metrics need to be aggregated across multiple entities like virtualservice </td>
<td> False </td>
</tr>
<tr>
<td> id </td>
<td> ID of the request. In case of GET API it is returned in the metrics query response. In case of collections API responses are grouped byresponses corresponding to each optimized query </td>
<td>  </td>
</tr>
<tr>
<td> page </td>
<td> page id for the query. Allowed only for aggregation queries </td>
<td>  </td>
</tr>
<tr>
<td> page_size </td>
<td> page size of the query. Allowed only for the aggregation queries </td>
<td>  </td>
</tr>
<tr>
<td> prediction </td>
<td> Request prediction values instead of actual observed metrics in future if supported. </td>
<td>  </td>
</tr>
<tr>
<td> microservice_levels </td>
<td> number of levels of microservices map </td>
<td> 0 </td>
</tr>
<tr>
<td> aggregate_obj_id </td>
<td> Aggregate metrics for all the records for obj_id. When this is set obj_id is treated as a filter rather than a dimension. </td>
<td> False </td>
</tr>
</table>
</div>
<h2 class='text-primary'> L4_Server Metrics </h2>
<div class='container-fluid'>
<p>
Virtualservice, Pool and Backend Network (Layer 4) Metrics
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> l4_server.apdexc </td>
<td> apdex for server based on connections </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.avg_available_capacity </td>
<td> Maximum available capacity of server in connections/s. It is difference between the max_capacity  and averaged load on the server </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.avg_bandwidth </td>
<td> Average transmit and receive network bandwidth between client and virtual service. </td>
<td> BITS_PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.avg_capacity </td>
<td> Average of max capacity of a server in connections/sacross all micro service engines. Pool level metric reflects averaged max capacity across all the servers in the pool. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.avg_complete_conns </td>
<td> Rate of total connections per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.avg_connections_dropped </td>
<td> Rate of dropped connections per second </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.avg_errored_connections </td>
<td> Rate of total errored connections per second </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.avg_est_capacity </td>
<td> Avg of estimated capacity of a server in connections/ssummed across all micro service engines. Pool level metric reflects summed estimated capacity across all the servers in the pool. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.avg_goodput </td>
<td> Actual application data goodput as bytes per second </td>
<td> BYTES_PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.avg_health_status </td>
<td> Status of the server. 0 is down 100 is up </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.avg_lossy_connections </td>
<td> Rate of lossy connections per second </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.avg_new_established_conns </td>
<td> Average rate new pool server connections established as per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.avg_open_conns </td>
<td> Avg number of open connections </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG, HOLTWINTERS_AT_AS </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.avg_pool_bandwidth </td>
<td> Average transmit and receive network bandwidth between client and virtual service across all servers in a Pool. </td>
<td> BITS_PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.avg_pool_complete_conns </td>
<td> Avg. Rate of total connections per second across  all servers </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.avg_pool_errored_connections </td>
<td> Average rate of total errored connections per second averaged across all servers in a Pool </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.avg_pool_new_established_conns </td>
<td> Average rate of new pool server connections established as per second across all servers </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.avg_pool_open_conns </td>
<td> Average per server open connections in the pool </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.avg_rx_bytes </td>
<td> Average rate of bytes received per second </td>
<td> BYTES_PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.avg_rx_goodput </td>
<td> Actual application receive data goodput as bytes per second </td>
<td> BYTES_PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.avg_rx_pkts </td>
<td> Average rate of packets received per second </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.avg_server_count </td>
<td> Server Count </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.avg_server_uptime </td>
<td> Server Uptime in % </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.avg_syns_sent </td>
<td> Total syncs sent across all connections </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.avg_total_rtt </td>
<td> Averaged RTT across all connections closed </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.avg_tx_bytes </td>
<td> Average rate of bytes transmitted per second </td>
<td> BYTES_PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.avg_tx_goodput </td>
<td> Actual application transmit data goodput as bytes per second </td>
<td> BYTES_PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.avg_tx_pkts </td>
<td> Average rate of packets transmitted per second </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.avg_uptime </td>
<td> Averaged server Uptime as percent of time it was up </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.max_available_capacity </td>
<td> Maximum available capacity of server in connections/s. It is difference between the max_capacity  and averaged load on the server </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.max_capacity </td>
<td> Maximum capacity of a server in connections/sacross all micro service engines. Pool level metric reflects maximum capacity across all the servers in the pool. This metric's 1 day value would represent maximum capacity over any .real time window over that 1 day window </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.max_connection_estb_time_be </td>
<td> Maximum connection establishment time on the server side. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.max_open_conns </td>
<td> Max number of open connections </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.max_rx_bytes_absolute </td>
<td> Total number of received bytes </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.max_rx_pkts_absolute </td>
<td> Total number of received frames </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.max_tx_bytes_absolute </td>
<td> Total number of transmitted bytes </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.max_tx_pkts_absolute </td>
<td> Total number of transmitted frames </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.pct_connection_errors </td>
<td> Percent of l4 connection dropped and lossy for server </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.pct_connection_saturation </td>
<td> Saturation percent of server in percent </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.sum_conn_duration </td>
<td> Total duration across all connections </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.sum_conn_est_time_exceeded_flows_be </td>
<td> Total number of times server side connection establishment time was breached. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.sum_connection_errors </td>
<td> Total number of client network connections that were lossy or dropped. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.sum_connection_setup_time </td>
<td> Total connection setup time across all connections </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.sum_connections_dropped </td>
<td> Total connections dropped including failed </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.sum_dup_ack_retransmits </td>
<td> Total duplicate ACK retransmits across all connections </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.sum_finished_conns </td>
<td> Total number of finished connections </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.sum_health_check_failures </td>
<td> total number of times this server was marked down </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.sum_lb_fail_count </td>
<td> Number of times load balancing failed </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.sum_lossy_connections </td>
<td> Total connections that were lossy due to high packet retransmissions. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.sum_lossy_req </td>
<td> Total requests that were lossy due to high packet retransmissions. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_server.sum_num_state_changes </td>
<td> Number of server up/down state changes in the previous period </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.sum_out_of_orders </td>
<td> Total out of order packets across all connections </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.sum_rtt </td>
<td> Total RTT across all connections </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.sum_rtt_valid_connections </td>
<td> Total number connections used for rtt </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.sum_rx_tcp_resets </td>
<td> Total number of RCP resets sent across all connections </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.sum_rx_zero_window_size_events </td>
<td> Total number of receive zero window size events across all connections </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.sum_sack_retransmits </td>
<td> Total SACK retransmits across all connections </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.sum_timeout_retransmits </td>
<td> Total connection timeouts in the interval </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_server.sum_tx_zero_window_size_events </td>
<td> Total number of transmit zero window size events across all connections </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
</table>
</div>
<h2 class='text-primary'> L4_Client Metrics </h2>
<div class='container-fluid'>
<p>
Virtualservice frontend Network (Layer 4) Metrics
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> l4_client.apdexc </td>
<td> apdex measuring quality of network connections to servers </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.apdexrtt </td>
<td> apdex measuring network connection quality based on RTT </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.avg_application_dos_attacks </td>
<td> Number of Application DDOS attacks occurring </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.avg_bandwidth </td>
<td> Average transmit and receive network bandwidth between client and virtual service. </td>
<td> BITS_PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG, HOLTWINTERS_AT_AS </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.avg_bytes_policy_drops </td>
<td> Averaged rate bytes dropped per second. </td>
<td> BYTES_PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_complete_conns </td>
<td> Rate of total connections per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG, HOLTWINTERS_AT_AS </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.avg_connections_dropped </td>
<td> Rate of dropped connections per second </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.avg_dos_app_error </td>
<td> DoS attack: Rate of HTTP App Errors </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_attacks </td>
<td> Number DDOS attacks occurring </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.avg_dos_bad_rst_flood </td>
<td> DoS attack: Rate of Bad Rst Floods </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_bandwidth </td>
<td> Average transmit and receive network bandwidth between client and virtual service related to DDoS attack. </td>
<td> BITS_PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.avg_dos_conn </td>
<td> Number of connections considered as DoS </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_conn_ip_rl_drop </td>
<td> DoS attack: Connections dropped due to IP rate limit </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_conn_rl_drop </td>
<td> DoS attack: Connections dropped due to VS rate limit </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_fake_session </td>
<td> DoS attack: Rate of Fake Sessions </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_http_abort </td>
<td> DoS attack: Rate of HTTP Aborts </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_http_error </td>
<td> DoS attack: Rate of HTTP Errors </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_http_timeout </td>
<td> DoS attack: Rate of HTTP Timeouts </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_malformed_flood </td>
<td> DoS attack: Rate of Malformed Packet Floods </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_non_syn_flood </td>
<td> DoS attack: Non SYN packet flood </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_req </td>
<td> Number of request considered as DoS </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_req_cookie_rl_drop </td>
<td> DoS attack: Requests dropped due to Cookie rate limit </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_req_custom_rl_drop </td>
<td> DoS attack: Requests dropped due to Custom rate limit </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_req_hdr_rl_drop </td>
<td> DoS attack: Requests dropped due to Header rate limit </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_req_ip_rl_drop </td>
<td> DoS attack: Requests dropped due to IP rate limit </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_req_ip_rl_drop_bad </td>
<td> DoS attack: Requests dropped due to IP rate limit for bad requests </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_req_ip_scan_bad_rl_drop </td>
<td> DoS attack: Requests dropped due to bad IP rate limit </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_req_ip_scan_unknown_rl_drop </td>
<td> DoS attack: Requests dropped due to unknown IP rate limit </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_req_ip_uri_rl_drop </td>
<td> DoS attack: Requests dropped due to IP+URL rate limit </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_req_ip_uri_rl_drop_bad </td>
<td> DoS attack: Requests dropped due to IP+URL rate limit for bad requests </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_req_rl_drop </td>
<td> DoS attack: Requests dropped due to VS rate limit </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_req_uri_rl_drop </td>
<td> DoS attack: Requests dropped due to URL rate limit </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_req_uri_rl_drop_bad </td>
<td> DoS attack: Requests dropped due to URL rate limit for bad requests </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_req_uri_scan_bad_rl_drop </td>
<td> DoS attack: Requests dropped due to bad URL rate limit </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_req_uri_scan_unknown_rl_drop </td>
<td> DoS attack: Requests dropped due to unknown URL rate limit </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_rx_bytes </td>
<td> Average rate of bytes received per second related to DDoS attack </td>
<td> BYTES_PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_slow_uri </td>
<td> DoS attack: Slow Uri </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_small_window_stress </td>
<td> DoS attack: Rate of Small Window Stresses </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_ssl_error </td>
<td> DoS attack: Rate of HTTP SSL Errors </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_syn_flood </td>
<td> DoS attack: Rate of Syn Floods </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_total_req </td>
<td> Total number of request used for L7 dos requests normalization </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_tx_bytes </td>
<td> Average rate of bytes transmitted per second related to DDoS attack </td>
<td> BYTES_PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_dos_zero_window_stress </td>
<td> DoS attack: Rate of Zero Window Stresses </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_errored_connections </td>
<td> Rate of total errored connections per second </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.avg_half_open_conns </td>
<td> Average rate of SYN DDoS attacks on Virtual Service. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG, HOLTWINTERS_AT_AS </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_l4_client_latency </td>
<td> Average L4 connection duration which does not include client RTT </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.avg_lossy_connections </td>
<td> Rate of lossy connections per second </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.avg_lossy_req </td>
<td> Averaged rate of lossy request per second. </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_network_dos_attacks </td>
<td> Number of Network DDOS attacks occurring </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.avg_new_established_conns </td>
<td> Averaged rate of new client connections per second. </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.avg_pkts_policy_drops </td>
<td> Averaged rate of dropped packets per second due to policy </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_policy_drops </td>
<td> Rate of total connections dropped due to VS policy per second. It includes drops due to rate limits, security policy drops, connection limits etc. </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.avg_rx_bytes </td>
<td> Average rate of bytes received per second </td>
<td> BYTES_PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.avg_rx_bytes_dropped </td>
<td> Average rate of received bytes dropped per second </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.avg_rx_pkts </td>
<td> Average rate of packets received per second </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.avg_rx_pkts_dropped </td>
<td> Average rate of received packets dropped per second </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.avg_syns </td>
<td> Total syncs sent across all connections </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_total_connections </td>
<td> Averaged rate bytes dropped per second. </td>
<td> BYTES_PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.avg_total_rtt </td>
<td> Average network round trip time between client and virtual service </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.avg_tx_bytes </td>
<td> Average rate of bytes transmitted per second </td>
<td> BYTES_PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.avg_tx_pkts </td>
<td> Average rate of packets transmitted per second </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.max_connection_estb_time_fe </td>
<td> Maximum connection establishment time on the client side. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.max_num_active_se </td>
<td> Max number of SEs. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.max_open_conns </td>
<td> Max number of open connections </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG, HOLTWINTERS_AT_AS </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.max_rx_bytes_absolute </td>
<td> Total number of received bytes </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.max_rx_pkts_absolute </td>
<td> Total number of received frames </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.max_tx_bytes_absolute </td>
<td> Total number of transmitted bytes </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.max_tx_pkts_absolute </td>
<td> Total number of transmitted frames </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.pct_application_dos_attacks </td>
<td> Fraction of L7 requests owing to DoS. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.pct_connection_errors </td>
<td> Percent of l4 connection dropped and lossy for virtual service </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.pct_connections_dos_attacks </td>
<td> Fraction of L4 connections owing to DoS. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.pct_dos_bandwidth </td>
<td> DoS bandwidth percentage. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.pct_dos_rx_bytes </td>
<td> Percentage of received bytes as part of a DoS attack. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.pct_network_dos_attacks </td>
<td> Deprecated </td>
<td>  </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.pct_pkts_dos_attacks </td>
<td> Fraction of packets owing to DoS. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.pct_policy_drops </td>
<td> Fraction of L4 requests dropped owing to policy. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.sum_conn_duration </td>
<td> Total duration across all connections </td>
<td> SECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.sum_conn_est_time_exceeded_flows_fe </td>
<td> Total number of times client side connection establishment time was breached. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.sum_connection_dropped_user_limit </td>
<td> Total number of connection dropped due to vserver connection limit </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.sum_connection_errors </td>
<td> Total number of client network connections that were lossy or dropped. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.sum_connections_dropped </td>
<td> Total connections dropped including failed </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.sum_dup_ack_retransmits </td>
<td> Total duplicate ACK retransmits across all connections </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.sum_end_to_end_rtt </td>
<td> Sum of end to end network RTT experienced by end clients. Higher value would increase response times experienced by clients. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.sum_end_to_end_rtt_bucket1 </td>
<td> Total connections that have RTT values from 0 to RTT threshold </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.sum_end_to_end_rtt_bucket2 </td>
<td> Total connections that have RTT values RTT threshold and above </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.sum_finished_conns </td>
<td> Total number of finished connections </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.sum_ingress_latency_exceeded_flows </td>
<td> Total number of times 'latency_threshold' was breached during ingress. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.sum_lossy_connections </td>
<td> Total connections that were lossy due to high packet retransmissions. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.sum_lossy_req </td>
<td> Total requests that were lossy due to high packet retransmissions. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l4_client.sum_out_of_orders </td>
<td> Total out of order packets across all connections </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.sum_packet_dropped_user_bandwidth_limit </td>
<td> Total number of packets dropped due to vserver bandwidth limit </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.sum_rtt_valid_connections </td>
<td> Total number connections used for rtt </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.sum_sack_retransmits </td>
<td> Total SACK retransmits across all connections </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.sum_server_flow_control </td>
<td> Total number of connections with server flow control condition </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.sum_timeout_retransmits </td>
<td> Total connection timeouts in the interval </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l4_client.sum_zero_window_size_events </td>
<td> Total number of zero window size events across all connections </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
</table>
</div>
<h2 class='text-primary'> L7_Server Metrics </h2>
<div class='container-fluid'>
<p>
Virtualservice, Pool and Backend Application (Layer 7) Metrics
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> l7_server.apdexr </td>
<td> apdex measuring response quality of server </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_server.avg_application_response_time </td>
<td> Average latency measured for pool server </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_server.avg_complete_responses </td>
<td> Rate of HTTP responses sent per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_server.avg_error_responses </td>
<td> Rate of HTTP error responses sent per second. It does not include errors excluded in analytics profile. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_server.avg_errors_excluded </td>
<td> Rate of HTTP responses excluded as errors based on analytics profile </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.avg_frustrated_responses </td>
<td> Avg number of HTTP requests that completed within frustrated latency </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_server.avg_pool_complete_responses </td>
<td> Avg rate of HTTP responses sent per second across all servers in a pool </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_server.avg_pool_error_responses </td>
<td> Average rate of HTTP responses sent per second across all servers in a pool </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_server.avg_reqs_per_session </td>
<td> Average number of requests per sessions closed in the interval </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.avg_resp_1xx </td>
<td> Rate of 1xx HTTP responses sent per second </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_server.avg_resp_2xx </td>
<td> Rate of 2xx HTTP responses sent per second </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_server.avg_resp_3xx </td>
<td> Rate of 3xx HTTP responses sent per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_server.avg_resp_4xx </td>
<td> Rate of 4xx HTTP responses sent per second </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_server.avg_resp_4xx_errors </td>
<td> Rate of 4xx HTTP responses as errors sent per second. It does not include any error codes excluded in the analytics profile </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_server.avg_resp_4xx_errors_excluded </td>
<td> Rate of 4xx HTTP responses excluded as errors based on analytics profile </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.avg_resp_5xx </td>
<td> Rate of 5xx HTTP responses sent per second </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_server.avg_resp_5xx_errors </td>
<td> Rate of 5xx HTTP responses as errors sent per second. It does not include any error codes excluded in the analytics profile </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_server.avg_resp_5xx_errors_excluded </td>
<td> Rate of 4xx HTTP responses excluded as errors based on analytics profile </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.avg_resp_latency </td>
<td> Average latency measured for pool server </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_server.avg_satisfactory_responses </td>
<td> Avg number of HTTP requests that completed within satisfactory latency </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_server.avg_server_count </td>
<td> Server count </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.avg_server_uptime </td>
<td> Server Uptime in % </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.avg_timeouts </td>
<td> Average number of requests that timeouted out. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.avg_tolerated_responses </td>
<td> Avg number of HTTP requests that completed within tolerated latency </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_server.avg_total_requests </td>
<td> Average rate of HTTP requests received by a pool's server per second. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_server.max_concurrent_sessions </td>
<td> Maximum number of concurrent HTTP sessions </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.pct_response_errors </td>
<td> Percent of HTTP 4xx and 5xx responses </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_server.sum_application_response_time </td>
<td> Average latency measured for pool server </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.sum_finished_sessions </td>
<td> Number of server sessions closed in this interval </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.sum_get_reqs </td>
<td> Total number of HTTP GET requests </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_server.sum_get_resp_latency </td>
<td> Total latency from responses to all the GET requests </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.sum_get_resp_latency_bucket1 </td>
<td> Total number of HTTP GET requests that were responded satisfactorily within latency threshold </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.sum_get_resp_latency_bucket2 </td>
<td> Total number of HTTP GET requests that were responded beyond latency threshold but within tolerated limits </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.sum_lb_fail_count </td>
<td> Number of times load balancing failed </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.sum_other_reqs </td>
<td> Total number of HTTP requests that are not GET or POST requests </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_server.sum_other_resp_latency </td>
<td> Total latency from responses to all the requests other than GET or POST </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.sum_other_resp_latency_bucket1 </td>
<td> Total number of HTTP requests other than GET or POST that were responded satisfactorily within latency threshold </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.sum_other_resp_latency_bucket2 </td>
<td> Total number of HTTP requests other than GET or POST that were responded beyond latency threshold but within tolerated limits </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.sum_post_reqs </td>
<td> Total number of HTTP POST requests </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_server.sum_post_resp_latency </td>
<td> Total latency from responses to all the POST requests </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.sum_post_resp_latency_bucket1 </td>
<td> Total number of HTTP POST requests that were responded satisfactorily within latency threshold </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.sum_post_resp_latency_bucket2 </td>
<td> Total number of HTTP POST requests that were responded beyond latency threshold but within tolerated limits </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.sum_reqs_finished_sessions </td>
<td> Total number of requests served across server sessions closed in the interval </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.sum_resp_1xx </td>
<td> Total number of HTTP 1XX responses </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.sum_resp_2xx </td>
<td> Total number of HTTP 2XX responses </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.sum_resp_3xx </td>
<td> Total number of HTTP 3XX responses </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.sum_resp_4xx </td>
<td> Total number of HTTP 4XX error responses </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.sum_resp_5xx </td>
<td> Total number of HTTP 5XX error responses </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_server.sum_total_responses </td>
<td> Total number of HTTP responses sent </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> L7_Client Metrics </h2>
<div class='container-fluid'>
<p>
Virtualservice frontend application (Layer 7) Metrics
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> l7_client.apdexr </td>
<td> Client Apdex measures quality of server response based on latency </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_application_response_time </td>
<td> Average server/application response latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_blocking_time </td>
<td> Average time client was blocked as reported by client </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_browser_rendering_time </td>
<td> Average browser rendering latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_cache_bytes </td>
<td> Average cache bytes </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_cache_hits </td>
<td> Average cache hit of requests </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_cacheable_bytes </td>
<td> Average cacheable bytes </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_cacheable_hits </td>
<td> Average cacheable hit of requests </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_client_data_transfer_time </td>
<td> Average client data transfer time that represents latency of sending response to the client excluding the RTT time . Higher client data transfer time signifies lower bandwidth  between client and Avi Service Engine </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_client_rtt </td>
<td> Average client Round Trip Time </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_client_txn_latency </td>
<td> Average client transaction latency computed by adding response latencies across all HTTP requests. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_complete_responses </td>
<td> Rate of HTTP responses sent per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG, HOLTWINTERS_AT_AS </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_connection_time </td>
<td> Average client connection latency reported by client </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_dns_lookup_time </td>
<td> Average domain lookup latency reported by client </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_dom_content_load_time </td>
<td> Average Dom content Load Time reported by clients </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_error_responses </td>
<td> Rate of HTTP error responses sent per second. It does not include errors excluded in analytics profile. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_errors_excluded </td>
<td> Rate of HTTP responses excluded as errors based on analytics profile </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_frustrated_responses </td>
<td> Avg number of HTTP requests that completed within frustrated latency </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_http_headers_bytes </td>
<td> Average size of HTTP headers per request. </td>
<td> BYTES </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_http_headers_count </td>
<td> Average number of HTTP headers per request. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_http_params_count </td>
<td> Average number of HTTP request parameters per request. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_page_download_time </td>
<td> Average Page Load time reported by clients </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_page_load_time </td>
<td> Average Page Load Time reported by client </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_params_per_req </td>
<td> Average number of HTTP request parameters per request, taking into account only requests with parameters. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_post_bytes </td>
<td> Average size of HTTP POST request. </td>
<td> BYTES </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_post_compression_bytes </td>
<td> Average post compression bytes </td>
<td> BYTES_PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_pre_compression_bytes </td>
<td> Average pre compression bytes </td>
<td> BYTES_PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_redirection_time </td>
<td> Average redirect latency reported by client </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_reqs_per_session </td>
<td> Average requests per session measured for closed sessions </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_resp_1xx </td>
<td> Rate of 1xx HTTP responses sent per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_resp_2xx </td>
<td> Rate of 2xx HTTP responses sent per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_resp_3xx </td>
<td> Rate of 3xx HTTP responses sent per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_resp_4xx </td>
<td> Rate of 4xx HTTP responses sent per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_resp_4xx_avi_errors </td>
<td> Rate of 4xx HTTP responses as errors sent by avi. It does not include any error codes excluded in the analytics profile and pool server errors </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_resp_5xx </td>
<td> Rate of 5xx HTTP responses sent per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_resp_5xx_avi_errors </td>
<td> Rate of 5xx HTTP responses as errors sent by avi. It does not include any error codes excluded in the analytics profile and pool server errors </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_rum_client_data_transfer_time </td>
<td> Total client data transfer time by client </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_satisfactory_responses </td>
<td> Avg number of HTTP requests that completed within satisfactory latency </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_server_rtt </td>
<td> Average server Round Trip Time </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_service_time </td>
<td> Average latency from receipt of request to start of response </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_ssl_auth_dsa </td>
<td> Average SSL Sessions using DSA certificate </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_ssl_auth_ecdsa </td>
<td> Average SSL Sessions using Elliptic Curve DSA (ECDSA) certificates </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_ssl_auth_rsa </td>
<td> Average SSL Sessions using RSA certificate </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_ssl_connections </td>
<td> Average SSL Sessions </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_ssl_ecdsa_non_pfs </td>
<td> Average SSL Exchanges using EC Cerificates without PFS </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_ssl_ecdsa_pfs </td>
<td> Average SSL Exchanges using EC Cerificates and PFS </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_ssl_errors </td>
<td> Average SSL errors due to clients, protocol errors,network errors and handshake timeouts </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_ssl_failed_connections </td>
<td> Average SSL connections failed due to protocol , network or timeout reasons </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_ssl_handshake_network_errors </td>
<td> Average SSL handshakes failed due to network errors </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_ssl_handshake_protocol_errors </td>
<td> Average SSL handshake failed due to clients or protocol errors </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_ssl_handshakes_new </td>
<td> Average new successful SSL sessions </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_ssl_handshakes_non_pfs </td>
<td> Average SSL Exchanges using Non-PFS </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_ssl_handshakes_pfs </td>
<td> Average SSL Exchanges using PFS </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_ssl_handshakes_reused </td>
<td> Average new successful resumed SSL sessions </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_ssl_handshakes_timedout </td>
<td> Average SSL handshakes timed out </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_ssl_kx_dh </td>
<td> Average SSL Exchanges using Diffie-Hellman </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_ssl_kx_ecdh </td>
<td> Average SSL Exchanges using RSA </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_ssl_kx_rsa </td>
<td> Average SSL Exchanges using RSA </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_ssl_rsa_non_pfs </td>
<td> Average SSL Exchanges using RSA Cerificates without PFS </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_ssl_rsa_pfs </td>
<td> Average SSL Exchanges using RSA Cerificates and PFS </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_ssl_ver_ssl30 </td>
<td> Average SSL Sessions with version 3.0 </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_ssl_ver_tls10 </td>
<td> Average SSL Sessions with TLS version 1.0 </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_ssl_ver_tls11 </td>
<td> Average SSL Sessions with TLS version 1.1 </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_ssl_ver_tls12 </td>
<td> Average SSL Sessions with TLS version 1.2 </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_ssl_ver_tls13 </td>
<td> Average SSL Sessions with TLS version 1.3 </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.avg_tolerated_responses </td>
<td> Avg number of HTTP requests that completed within tolerated latency </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_total_http2_requests </td>
<td> Average number of client HTTP2 requests received by the Virtual Service per second. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_total_requests </td>
<td> Average rate of client HTTP requests received by the virtual service per second. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_uri_length </td>
<td> Average length of HTTP URI per request. </td>
<td> BYTES </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_attacks </td>
<td> Average number of transactions per second identified by WAF as attacks. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG, HOLTWINTERS_AT_AS </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_disabled </td>
<td> Average number of transactions per second bypassing WAF. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_evaluated </td>
<td> Average number of transactions per second evaluated by WAF. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_evaluated_request_body_phase </td>
<td> Average number of requests per second evaluated by WAF in Request Body Phase. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_evaluated_request_header_phase </td>
<td> Average number of requests per second evaluated by WAF in Request Header Phase. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_evaluated_response_body_phase </td>
<td> Average number of responses per second evaluated by WAF in Response Body Phase. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_evaluated_response_header_phase </td>
<td> Average number of responsess per second evaluated by WAF in Response Header Phase. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_flagged </td>
<td> Average number of transactions per second flagged by WAF. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_flagged_request_body_phase </td>
<td> Average number of requests per second flagged (but not rejected) by WAF in Request Body Phase. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_flagged_request_header_phase </td>
<td> Average number of requests per second flagged (but not rejected) by WAF in Request Header Phase. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_flagged_response_body_phase </td>
<td> Average number of responses per second flagged (but not rejected) by WAF in Response Body Phase. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_flagged_response_header_phase </td>
<td> Average number of responses per second flagged (but not rejected) by WAF in Response Header Phase. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_latency_request_body_phase </td>
<td> Average waf latency seen due to WAF Request Body processing. </td>
<td> MICROSECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_latency_request_header_phase </td>
<td> Average waf latency seen due to WAF Request Header processing. </td>
<td> MICROSECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_latency_response_body_phase </td>
<td> Average waf latency seen due to WAF Response Body processing. </td>
<td> MICROSECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_latency_response_header_phase </td>
<td> Average waf latency seen due to WAF Response Header processing. </td>
<td> MICROSECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_matched </td>
<td> Average number of transactions per second matched by WAF rule/rules. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_matched_request_body_phase </td>
<td> Average number of requests per second matched by WAF in Request Body Phase. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_matched_request_header_phase </td>
<td> Average number of requests per second matched by WAF in Request Header Phase. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_matched_response_body_phase </td>
<td> Average number of responses per second matched by WAF in Response Body Phase. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_matched_response_header_phase </td>
<td> Average number of responses per second matched by WAF in Response Header Phase. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_rejected </td>
<td> Average number of transactions per second rejected by WAF. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_rejected_request_body_phase </td>
<td> Average number of requests per second rejected by WAF in Request Body Phase. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_rejected_request_header_phase </td>
<td> Average number of requests per second rejected by WAF in Request Header Phase. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_rejected_response_body_phase </td>
<td> Average number of responses per second rejected by WAF in Response Body Phase. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waf_rejected_response_header_phase </td>
<td> Average number of responses per second rejected by WAF in Response Header Phase. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.avg_waiting_time </td>
<td> Average Waiting Time reported by client </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.max_concurrent_sessions </td>
<td> Maximum number of concurrent HTTP sessions </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.max_ssl_open_sessions </td>
<td> Maximum number of open SSL sessions </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.pct_cache_hits </td>
<td> Percentage cache hit of requests </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.pct_cacheable_hits </td>
<td> Percentage cacheable hit of requests </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.pct_get_reqs </td>
<td> Number of HTTP GET requests as a percentage of total requests received. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.pct_post_reqs </td>
<td> Number of HTTP POST requests as a percentage of total requests received. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.pct_response_errors </td>
<td> Percent of 4xx and 5xx responses </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.pct_ssl_failed_connections </td>
<td> Percent of SSL connections failured due to protocol , network or timeout reasons </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.pct_waf_attacks </td>
<td> Malicious transactions (Attacks) identified by WAF as the pecentage  of total requests received. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.pct_waf_disabled </td>
<td> Transactions bypassing WAF as the percentage of total requests received. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.pct_waf_evaluated </td>
<td> WAF evaluated transactions as the pecentage of total requests received. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.pct_waf_flagged </td>
<td> WAF flagged transactions as the percentage of total WAF evaluated transactions. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.pct_waf_matched </td>
<td> WAF matched requests as the percentage of total WAF evaluated requests. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.pct_waf_rejected </td>
<td> WAF rejected transactions as the percentage of total WAF evaluated transactions. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.rum_apdexr </td>
<td> Apdex measures quality of server response based on Real User Metric </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.ssl_protocol_strength </td>
<td> Protocol strength of SSL ciphers used. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_application_response_time </td>
<td> Total time taken by server to respond to requesti </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_blocking_time </td>
<td> Total time client was blocked </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_browser_rendering_time </td>
<td> Total browser rendering latency reported by client </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_client_data_transfer_time </td>
<td> Average client data transfer time computed by adding response latencies across all HTTP requests. </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_client_rtt </td>
<td> Sum of all client Round Trip Times for all samples </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_connection_time </td>
<td> Total client connection latency reported by client </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_dns_lookup_time </td>
<td> Total domain lookup latency reported by client </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_dom_content_load_time </td>
<td> Total dom content latency reported by client </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_errors </td>
<td> Count of HTTP 400 and 500 errors for a virtual service in a time interval. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_finished_sessions </td>
<td> Number of server sessions closed in this interval </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_get_client_txn_latency </td>
<td> Total latency from responses to all the GET requests </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_get_client_txn_latency_bucket1 </td>
<td> Total number of HTTP GET requests that were responded satisfactorily within latency threshold </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_get_client_txn_latency_bucket2 </td>
<td> Total number of HTTP GET requests that were responded beyond latency threshold but within tolerated limits </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_get_reqs </td>
<td> Total number of HTTP GET requests </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_http_headers_bytes </td>
<td> Total size of HTTP request headers. </td>
<td> BYTES </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_http_headers_count </td>
<td> Total number of HTTP headers across all requests in a given metrics interval. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_http_params_count </td>
<td> Total number of HTTP request parameters. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_num_page_load_time_bucket1 </td>
<td> Total samples that had satisfactory page load time </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_num_page_load_time_bucket2 </td>
<td> Total samples that had tolerated page load time </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_num_rum_samples </td>
<td> Total samples used for rum metrics </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_other_client_txn_latency </td>
<td> Total latency from responses to all the requests other than GET or POST </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_other_client_txn_latency_bucket1 </td>
<td> Total number of HTTP requests other than GET or POST that were responded satisfactorily within latency threshold </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_other_client_txn_latency_bucket2 </td>
<td> Total number of HTTP requests other than GET or POST that were responded beyond latency threshold but within tolerated limits </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_other_reqs </td>
<td> Total number of HTTP requests that are not GET or POST requests </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_page_download_time </td>
<td> Total time to transfer response to client </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_page_load_time </td>
<td> Total Page Load Time reported by client </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_post_bytes </td>
<td> Total size of HTTP POST requests. </td>
<td> BYTES </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_post_client_txn_latency </td>
<td> Total latency from responses to all the POST requests </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_post_client_txn_latency_bucket1 </td>
<td> Total number of HTTP POST requests that were responded satisfactorily within latency threshold </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_post_client_txn_latency_bucket2 </td>
<td> Total number of HTTP POST requests that were responded beyond latency threshold but within tolerated limits </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_post_reqs </td>
<td> Total number of HTTP POST requests </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_redirection_time </td>
<td> Total redirect latency reported by client </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_reqs_finished_sessions </td>
<td> Total number of requests served across server sessions closed in the interval </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_reqs_with_params </td>
<td> Total number of HTTP requests containing at least one parameter. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_resp_1xx </td>
<td> Total number of HTTP 1XX responses </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_resp_2xx </td>
<td> Total number of HTTP 2XX responses </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_resp_3xx </td>
<td> Total number of HTTP 3XX responses </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_resp_4xx </td>
<td> Total number of HTTP 4XX error responses </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_resp_5xx </td>
<td> Total number of HTTP 5XX error responses </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_rum_client_data_transfer_time </td>
<td> Total client data transfer time by client </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_server_rtt </td>
<td> Sum of all server Round Trip Times for all samples </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_service_time </td>
<td> Total time from receipt of request to start of response </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_total_responses </td>
<td> Total number of HTTP responses sent </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_uri_length </td>
<td> Total length of HTTP request URIs. </td>
<td> BYTES </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> l7_client.sum_waf_attacks </td>
<td> Total number of transactions identified by WAF as attacks. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_waf_disabled </td>
<td> Total number of requests bypassing WAF. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_waf_evaluated_request_body_phase </td>
<td> Total number of requests evaluated by WAF in Request Body Phase. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_waf_evaluated_request_header_phase </td>
<td> Total number of requests evaluated by WAF in Request Header Phase. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_waf_evaluated_response_body_phase </td>
<td> Total number of responses evaluated by WAF in Response Body Phase. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_waf_evaluated_response_header_phase </td>
<td> Total number of responses evaluated by WAF in Response Header Phase. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_waf_flagged </td>
<td> Total number of transactions (requests or responses) flagged as attack by WAF. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_waf_flagged_request_body_phase </td>
<td> Total number of requests flagged (but not rejected) by WAF in Request Body Phase. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_waf_flagged_request_header_phase </td>
<td> Total number of requests flagged (but not rejected) by WAF in Request Header Phase. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_waf_flagged_response_body_phase </td>
<td> Total number of responses flagged (but not rejected) by WAF in Response Body Phase. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_waf_flagged_response_header_phase </td>
<td> Total number of responses flagged (but not rejected) by WAF in Response Header Phase. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_waf_latency_request_body_phase </td>
<td> Total latency seen by all evaluated requests in Request Body Phase </td>
<td> MICROSECONDS </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_waf_latency_request_header_phase </td>
<td> Total latency seen by all transactions evaluated by WAF in Request Header Phase </td>
<td> MICROSECONDS </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_waf_latency_response_body_phase </td>
<td> Total latency seen by all evaluated responses in Response Body Phase </td>
<td> MICROSECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_waf_latency_response_header_phase </td>
<td> Total latency seen by all evaluated responsess in WAF Response Header Phase </td>
<td> MICROSECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_waf_matched_request_body_phase </td>
<td> Total number of requests matched by WAF in Request Body Phase. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_waf_matched_request_header_phase </td>
<td> Total number of requests matched by WAF in Request Header Phase. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_waf_matched_response_body_phase </td>
<td> Total number of responses matched by WAF in Response Body Phase. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_waf_matched_response_header_phase </td>
<td> Total number of responses matched by WAF in Response Header Phase. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_waf_rejected </td>
<td> Total number of transactions (requests or responses) rejected by WAF. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_waf_rejected_request_body_phase </td>
<td> Total number of requests rejected by WAF in Request Body Phase. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_waf_rejected_request_header_phase </td>
<td> Total number of requests rejected by WAF in Request Header Phase. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_waf_rejected_response_body_phase </td>
<td> Total number of responses rejected by WAF in Response Body Phase. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_waf_rejected_response_header_phase </td>
<td> Total number of responses rejected by WAF in Response Header Phase. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> l7_client.sum_waiting_time </td>
<td> Total waiting reported by client </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Vm_Stats Metrics </h2>
<div class='container-fluid'>
<p>
Virtualmachine Infrastructure Metrics
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> vm_stats.avg_cpu_maxlimited </td>
<td> Percent of time virtual machine was ready to run but had to wait due to CPU limits. This indicates potential configuration issue of not enough CPU assigned to the virtual machine. </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> vm_stats.avg_cpu_ready </td>
<td> Percent of time virtual machine was ready to run but had to wait as it could not be scheduled on physical CPU. This indicates CPU starvation for the virtual machine. </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> vm_stats.avg_cpu_usage </td>
<td> Average CPU usage as a percentage of CPU available to the server. </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> vm_stats.avg_cpu_wait </td>
<td> Percent of time virtual machine was ready to run either due to other VMs stealing CPU or hitting CPU limits configured in vCenter. </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> vm_stats.avg_cpus_system_time_secs </td>
<td> CPU time consumed in kernel land </td>
<td> SECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> vm_stats.avg_cpus_user_time_secs </td>
<td> CPU time consumed in user land </td>
<td> SECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> vm_stats.avg_disk1_usage </td>
<td> Virtual disk1 capacity usage. </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> vm_stats.avg_disk2_usage </td>
<td> Virtual disk2 capacity usage. </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> vm_stats.avg_disk3_usage </td>
<td> Virtual disk3 capacity usage. </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> vm_stats.avg_disk4_usage </td>
<td> Virtual disk4 capacity usage. </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> vm_stats.avg_disk_commands_aborted </td>
<td> Average rate of disk commands aborted </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> vm_stats.avg_disk_io </td>
<td> Rate of disk reads and writes </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> vm_stats.avg_disk_max_total_latency </td>
<td> Average max latency observed across all disks </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> vm_stats.avg_disk_number_read </td>
<td> Average number of times data was read from each virtual disk on the virtual machine </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> vm_stats.avg_disk_number_write </td>
<td> Average number of times data was written to each virtual disk on the virtual machine </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> vm_stats.avg_disk_read </td>
<td> Rate of reading data from the disk. </td>
<td> KILO_BITS_PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> vm_stats.avg_disk_write </td>
<td> Rate of writing data from the disk. </td>
<td> KILO_BITS_PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> vm_stats.avg_mem_swap_in </td>
<td> Total amount of data that has been read into machine memory from the swap file since the virtual machine was powered on </td>
<td> KILO_BYTES </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> vm_stats.avg_mem_swap_out </td>
<td> Total amount of data that the VMkernel has written to the virtual machine swap file from machine memory. This statistic refers to VMkernel swapping and not to guest OS swapping </td>
<td> KILO_BYTES </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> vm_stats.avg_mem_usage </td>
<td> Average memory usage as percentage of memory available to the server. </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> vm_stats.avg_mem_vmmemctl </td>
<td> Virtual machine: Amount of guest physical memory that is currently reclaimed from the virtual machine through ballooning. This is the amount of guest physical memory that has been allocated and pinned by the balloon driver </td>
<td> KILO_BYTES </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> vm_stats.avg_net_dropped </td>
<td> Rate of dropped network packets in both receive and transmit direction. This may be indication of potential network congestion. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> vm_stats.avg_net_dropped_rx </td>
<td> Average number of receive packets dropped </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> vm_stats.avg_net_dropped_tx </td>
<td> Average number of transmit packets dropped </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> vm_stats.avg_net_errors_rx </td>
<td> Average number of packets with errors received </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> vm_stats.avg_net_errors_tx </td>
<td> Average number of packets with errors transmitted </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> vm_stats.avg_net_received </td>
<td> Average network traffic received by the virtual machine </td>
<td> KILO_BITS_PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> vm_stats.avg_net_transmitted </td>
<td> Average network traffic transmitted by the virtual machine </td>
<td> KILO_BITS_PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> vm_stats.avg_net_usage </td>
<td> Combined transmit and receive bandwidth for virtual machine </td>
<td> KILO_BITS_PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> vm_stats.avg_port_usage </td>
<td> Percentage of high ports used </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> vm_stats.avg_uptime </td>
<td> Total % time VM was up during an interval. </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> vm_stats.avg_virtual_disk_commands_aborted </td>
<td> Number of SCSI commands aborted  </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> vm_stats.avg_virtual_disk_read </td>
<td> Rate of read data from the virtual disk. </td>
<td> KILO_BITS_PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> vm_stats.avg_virtual_disk_throughput_usage </td>
<td> Virtual disk I/O rate. </td>
<td> KILO_BITS_PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> vm_stats.avg_virtual_disk_write </td>
<td> Rate of read data from the virtual disk. </td>
<td> KILO_BITS_PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Se_Stats Metrics </h2>
<div class='container-fluid'>
<p>
ServiceEngine Metrics
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> se_stats.avg_connection_mem_usage </td>
<td> Connection memory usage as percentage of total allowed for connections </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.avg_connection_policy_drops </td>
<td> Total number of connections dropped at SE due to  policies configured in VS eg. security policy, rate limits connection limit, bandwidth limit etc. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.avg_connections </td>
<td> Average number of connections including the  dropped connections and ones due to policy drops. This would be same as number of SYNS seen by SE on any VS </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.avg_connections_dropped </td>
<td> Total number of connections dropped excluding the  dropped connections and ones due to policy drops. This would be same as number of SYNS seen by SE on any VS. It include both connections that failed to establish </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.avg_cpu_usage </td>
<td> This is the host's view of the CPU usage as amount of actively used virtual CPU, as a percentage of total available CPU </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.avg_disk1_usage </td>
<td> SE disk 1 capacity usage. </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.avg_dos_icmp_flood </td>
<td> DoS attack: Icmp Ping Flood </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.avg_dos_ip_frag_full </td>
<td> DoS attack: Ip Fragmentation Full </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.avg_dos_ip_frag_incomplete </td>
<td> DoS attack: Ip Fragmentation Incomplete </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.avg_dos_ip_frag_overrun </td>
<td> DoS attack: Ip Fragmentation Overrun </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.avg_dos_ip_frag_toosmall </td>
<td> DoS attack: Ip Fragmentation Too Small </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.avg_dos_land </td>
<td> DoS attack: Land </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.avg_dos_port_scan </td>
<td> DoS attack: Port Scan </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.avg_dos_smurf </td>
<td> DoS attack: Smurf </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.avg_dos_tcp_non_syn_flood </td>
<td> DoS attack: Non Syn Flood (Deprecated) </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.avg_dos_teardrop </td>
<td> DoS attack: Teardrop </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.avg_dos_unknown_protocol </td>
<td> DoS attack: Unknown Protocol </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.avg_dynamic_mem_usage </td>
<td> Percentage of SE's dynamic memory usage. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.avg_egress_latency </td>
<td> Average egress queueing latency. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.avg_ingress_latency </td>
<td> Average ingress queueing latency. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.avg_mem_usage </td>
<td> Memory usage as percentage of total configured or available memory </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.avg_packet_buffer_header_usage </td>
<td> Packet Buffer usage as percentage of total packet buffer headers </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.avg_packet_buffer_large_usage </td>
<td> Packet Buffer usage as percentage of total large packet buffers </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.avg_packet_buffer_size </td>
<td> Total packet buffer size </td>
<td> MEGA_BYTES </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.avg_packet_buffer_small_usage </td>
<td> Packet Buffer usage as percentage of total small packet buffers </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.avg_packet_buffer_usage </td>
<td> Packet Buffer usage as percentage of total configured packet buffers </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.avg_persistent_table_size </td>
<td> session persistent table entries size </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.avg_persistent_table_usage </td>
<td> session persistent table entries usage percent </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.avg_rx_bytes_dropped </td>
<td> Avg. number of bytes per sec of received packets dropped. It includes packets across all VS and non VS </td>
<td> BYTES_PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.avg_rx_pkts_dropped </td>
<td> Avg. number of received packets dropped per sec. It includes packets across all VS and non VS </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.avg_shared_memory_usage </td>
<td> Shared memory usage as percentage of total available shared memory </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.avg_ssl_session_cache </td>
<td> ssl session cache </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.avg_ssl_session_cache_usage </td>
<td> ssl session cache usage in percent </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.avg_worst_egress_latency </td>
<td> Average of the worst case egress queueing latency. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.avg_worst_ingress_latency </td>
<td> Average of the worst case ingress queueing latency. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.max_connection_mem_total </td>
<td> Total memory available for connections on the Service Engine </td>
<td> MEGA_BYTES </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.max_connection_table_size </td>
<td> Number of connection/flow table entries </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.max_num_vs </td>
<td> Max number of vs </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.max_synseen_entries_size </td>
<td> Max size of synseen entries </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.max_total_memory </td>
<td> Total memory present on the Service Engine </td>
<td> MEGA_BYTES </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.pct_connections_dropped </td>
<td> Fraction of SE connections dropped. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.pct_rx_bytes_dropped </td>
<td> Fraction of SE bytes dropped. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.pct_rx_pkts_dropped </td>
<td> Fraction of SE packets dropped. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.pct_syn_cache_usage </td>
<td> Percentage of SYN cache usage. Higher usage indicates too many connection attempts and open at service engine </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.sum_arp_pkts_dropped </td>
<td> Number of data packets dropped waiting for ARP reply. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.sum_arp_pkts_received </td>
<td> Number of ARP packets received by this host. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.sum_arp_rx_replies </td>
<td> Number of ARP replies received by this host. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.sum_arp_rx_requests </td>
<td> Number of ARP requests received by this host. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.sum_arp_timeouts </td>
<td> Number of times pending ARP were entries removed due to timeout. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.sum_arp_tx_replies </td>
<td> Number of ARP replies sent by this host. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.sum_arp_tx_requests </td>
<td> Number of ARP requests sent by this host. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.sum_cache_object_allocation_failure </td>
<td> Number of times cacheable objects were dropped due to memory allocation failure </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.sum_connection_dropped_memory_limit </td>
<td> Number of times connection memory limit is reached </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.sum_connection_dropped_packet_buffer_stressed </td>
<td> Number of times connection is dropped because packet buffer limit is reached </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.sum_connection_dropped_persistence_table_limit </td>
<td> Number of times persistent table allocaction fails </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.sum_mbstats_mbuf_allocation_failures </td>
<td> Number of mbuf allocation failures. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.sum_mbstats_mbuf_available </td>
<td> Available memory buffers. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.sum_mbstats_mbuf_total </td>
<td> Total memory buffers. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.sum_mbstats_mcopy_fail </td>
<td> Number of failures in mem copy. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.sum_mbstats_pktbuf_allocation_failures </td>
<td> Number of failures in allocating packet buffers. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.sum_mbstats_pktbuf_available </td>
<td> Available packet buffer. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.sum_mbstats_pktbuf_total </td>
<td> Total packet buffer. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.sum_mbstats_small_pktbuf_allocation_failures </td>
<td> Number of small cluster buffers allocation failures. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.sum_mbstats_small_pktbuf_available </td>
<td> Number of small cluster buffers available. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.sum_mbstats_small_pktbuf_total </td>
<td> Number of total small cluster buffers. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_stats.sum_num_egress_latency_exceeded_pkts </td>
<td> Total number of times 'egress_threshold' was breached during egress. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.sum_num_ingress_latency_exceeded_pkts </td>
<td> Total number of times 'ingress_threshold' was breached during ingress. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.sum_packet_buffer_allocation_failure </td>
<td> Number of times packet buffer allocation failed </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> se_stats.sum_packet_dropped_packet_buffer_stressed </td>
<td> Number of times packet is dropped because packet buffer limit is reached </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Controller_Stats Metrics </h2>
<div class='container-fluid'>
<p>
Controller Metrics
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> controller_stats.avg_cpu_usage </td>
<td> This is the host's view of the CPU usage as amount of actively used virtual CPU, as a percentage of total available CPU </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.avg_disk_read_bytes </td>
<td> Average number of bytes per second read from disk. </td>
<td> BYTES_PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.avg_disk_usage </td>
<td> Average disk usage </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.avg_disk_write_bytes </td>
<td> Average number of bytes per second written to disk. </td>
<td> BYTES_PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.avg_mem_buffered </td>
<td> Average memory usage as part of OS bufferes. </td>
<td> KB </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.avg_mem_cached </td>
<td> Average memory usage as part of OS cache. </td>
<td> KB </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.avg_mem_usage </td>
<td> Memory usage as percentage of total configured or available memory </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.avg_num_active_vs </td>
<td> Current number of VS for the tenant </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.avg_num_backend_servers </td>
<td> Current number of unique IP:port servers in use as observed by the controller </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.avg_num_se_cores </td>
<td> Current number of CPU cores across all Service Engines </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.avg_num_service_cores </td>
<td> Average number of SE service cores for the tenant </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.avg_num_ses </td>
<td> Current number of SEs for the tenant </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.avg_num_sockets </td>
<td> (Deprecated) Average number of SE sockets for the tenant </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.avg_total_se_throughput </td>
<td> Current throughput across all Service Engines </td>
<td> BITS_PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.max_be_servers_lic_usage </td>
<td> (Deprecated) Maximum backend servers usage fraction. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.max_mem_usage </td>
<td> Max Memory usage as percentage of total configured or available memory </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.max_num_active_vs </td>
<td> Max number of VS for the tenant </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.max_num_active_vs_lic_usage </td>
<td> Maximum number of active VS usage fraction </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.max_num_backend_servers </td>
<td> Number of unique IP:port servers in use as observed by the controller </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.max_num_se_cores </td>
<td> Number of CPU cores across all Service Engines </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.max_num_service_cores </td>
<td> Max number of SE service cores for the tenant </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.max_num_service_cores_lic_usage </td>
<td> Maximum number of service cores usage fraction </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.max_num_ses </td>
<td> Max number of SEs for the tenant </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.max_num_ses_lic_usage </td>
<td> (Deprecated) Maximum number of SEs usage fraction </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.max_num_sockets </td>
<td> (Deprecated) Max number of SE sockets for the tenant </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.max_num_sockets_lic_usage </td>
<td> (Deprecated) Maximum number of SE sockets usage fraction </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.max_se_cores_lic_usage </td>
<td> (Deprecated) Maximum number of SE cores usage fraction </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.max_se_throughput_lic_usage </td>
<td> (Deprecated) Maximum throughput usage fraction </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.max_total_se_throughput </td>
<td> Total throughput across all Service Engines </td>
<td> BITS_PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.sum_total_se_bytes </td>
<td> Total bytes including ingress and egress traffic seen by the SE </td>
<td> BYTES </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.sum_total_vs_bytes </td>
<td> Sum of bytes including traffic from client and to backend servers, across all VS. </td>
<td> BYTES </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.sum_total_vs_client_bytes </td>
<td> Sum of bytes including traffic from client, across all VS. </td>
<td> BYTES </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> controller_stats.sum_total_vs_usage </td>
<td> Number of hours of Virtual Service usage </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Rum Metrics </h2>
<div class='container-fluid'>
<p>
Navigation Timing Metrics
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> rum.application_response_time </td>
<td> Total time browser waited due to application (Avi to server) latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum.blocking_time </td>
<td> Total time browser was blocked from loading page </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum.browser_rendering_time </td>
<td> Total time browser waited for rendering content </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum.client_rtt </td>
<td> Total time browser waited due to client network latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum.connection_time </td>
<td> Total time browser waited for connection setup </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum.dns_lookup_time </td>
<td> Total time browser waited for DNS resolution </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum.dom_content_load_time </td>
<td> Total time browser waited to load document content </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum.page_download_time </td>
<td> Total time browser waited receiving data </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum.page_load_time </td>
<td> Total time browser waited for loading page </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum.redirection_time </td>
<td> Total time browser waited for redirecting </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum.rum_client_data_transfer_time </td>
<td> Total time to send data from start of response to the end </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum.server_rtt </td>
<td> Total time browser waited due to application (Avi to server) network latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum.service_time </td>
<td> Total time for Avi response. It measures time spent from the first packet of client  request received by Avi until the first packet of Avi's response </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum.waiting_time </td>
<td> Total time browser waited get first byte of response </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Rum_Browser Metrics </h2>
<div class='container-fluid'>
<p>
Navigation Timings aggregated over dimension Browser
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> rum_browser.sum_application_response_time </td>
<td> Total time browser waited due to application (Avi to server) latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_browser.sum_blocking_time </td>
<td> Total time browser was blocked from loading page </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_browser.sum_browser_rendering_time </td>
<td> Total time browser waited for rendering content </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_browser.sum_client_rtt </td>
<td> Total time browser waited due to client network latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_browser.sum_connection_time </td>
<td> Total time browser waited for connection setup </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_browser.sum_dns_lookup_time </td>
<td> Total time browser waited for DNS resolution </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_browser.sum_dom_content_load_time </td>
<td> Total time browser waited for loading document cotent </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_browser.sum_page_download_time </td>
<td> Total time browser waited receiving data </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_browser.sum_page_load_time </td>
<td> Total time browser waited for loading page </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_browser.sum_redirection_time </td>
<td> Total time browser waited for redirecting </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_browser.sum_rum_client_data_transfer_time </td>
<td> Total time to send data from start of response to the end </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_browser.sum_server_rtt </td>
<td> Total time browser waited due to application (Avi to server) network latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_browser.sum_service_time </td>
<td> Total time for Avi response. It measures time spent from the first packet of client  request received by Avi until the first packet of Avi's response </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_browser.sum_waiting_time </td>
<td> Total time browser waited get first byte of response </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Rum_Url Metrics </h2>
<div class='container-fluid'>
<p>
Navigation Timings aggregated over dimension URL
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> rum_url.sum_application_response_time </td>
<td> Total time browser waited due to application (Avi to server) latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_url.sum_blocking_time </td>
<td> Total time browser was blocked from loading page </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_url.sum_browser_rendering_time </td>
<td> Total time browser waited for rendering content </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_url.sum_client_rtt </td>
<td> Total time browser waited due to client network latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_url.sum_connection_time </td>
<td> Total time browser waited for connection setup </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_url.sum_dns_lookup_time </td>
<td> Total time browser waited for DNS resolution </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_url.sum_dom_content_load_time </td>
<td> Total time browser waited for loading document cotent </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_url.sum_page_download_time </td>
<td> Total time browser waited receiving data </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_url.sum_page_load_time </td>
<td> Total time browser waited for loading page </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_url.sum_redirection_time </td>
<td> Total time browser waited for redirecting </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_url.sum_rum_client_data_transfer_time </td>
<td> Total time to send data from start of response to the end </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_url.sum_server_rtt </td>
<td> Total time browser waited due to application (Avi to server) network latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_url.sum_service_time </td>
<td> Total time for Avi response. It measures time spent from the first packet of client  request received by Avi until the first packet of Avi's response </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_url.sum_waiting_time </td>
<td> Total time browser waited get first byte of response </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Rum_Os Metrics </h2>
<div class='container-fluid'>
<p>
Navigation Timings aggregated over dimension Operating System
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> rum_os.sum_application_response_time </td>
<td> Total time browser waited due to application (Avi to server) latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_os.sum_blocking_time </td>
<td> Total time browser was blocked from loading page </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_os.sum_browser_rendering_time </td>
<td> Total time browser waited for rendering content </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_os.sum_client_rtt </td>
<td> Total time browser waited due to client network latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_os.sum_connection_time </td>
<td> Total time browser waited for connection setup </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_os.sum_dns_lookup_time </td>
<td> Total time browser waited for DNS resolution </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_os.sum_dom_content_load_time </td>
<td> Total time browser waited for loading document cotent </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_os.sum_page_download_time </td>
<td> Total time browser waited receiving data </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_os.sum_page_load_time </td>
<td> Total time browser waited for loading page </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_os.sum_redirection_time </td>
<td> Total time browser waited for redirecting </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_os.sum_rum_client_data_transfer_time </td>
<td> Total time to send data from start of response to the end </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_os.sum_server_rtt </td>
<td> Total time browser waited due to application (Avi to server) network latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_os.sum_service_time </td>
<td> Total time for Avi response. It measures time spent from the first packet of client  request received by Avi until the first packet of Avi's response </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_os.sum_waiting_time </td>
<td> Total time browser waited get first byte of response </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Rum_Lang Metrics </h2>
<div class='container-fluid'>
<p>
Navigation Timings aggregated over dimension Language
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> rum_lang.sum_application_response_time </td>
<td> Total time browser waited due to application (Avi to server) latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_lang.sum_blocking_time </td>
<td> Total time browser was blocked from loading page </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_lang.sum_browser_rendering_time </td>
<td> Total time browser waited for rendering content </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_lang.sum_client_rtt </td>
<td> Total time browser waited due to client network latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_lang.sum_connection_time </td>
<td> Total time browser waited for connection setup </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_lang.sum_dns_lookup_time </td>
<td> Total time browser waited for DNS resolution </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_lang.sum_dom_content_load_time </td>
<td> Total time browser waited for loading document cotent </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_lang.sum_page_download_time </td>
<td> Total time browser waited receiving data </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_lang.sum_page_load_time </td>
<td> Total time browser waited for loading page </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_lang.sum_redirection_time </td>
<td> Total time browser waited for redirecting </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_lang.sum_rum_client_data_transfer_time </td>
<td> Total time to send data from start of response to the end </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_lang.sum_server_rtt </td>
<td> Total time browser waited due to application (Avi to server) network latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_lang.sum_service_time </td>
<td> Total time for Avi response. It measures time spent from the first packet of client  request received by Avi until the first packet of Avi's response </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_lang.sum_waiting_time </td>
<td> Total time browser waited get first byte of response </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Rum_Devtype Metrics </h2>
<div class='container-fluid'>
<p>
Navigation Timings aggregated over dimension Device Type
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> rum_devtype.sum_application_response_time </td>
<td> Total time browser waited due to application (Avi to server) latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_devtype.sum_blocking_time </td>
<td> Total time browser was blocked from loading page </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_devtype.sum_browser_rendering_time </td>
<td> Total time browser waited for rendering content </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_devtype.sum_client_rtt </td>
<td> Total time browser waited due to client network latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_devtype.sum_connection_time </td>
<td> Total time browser waited for connection setup </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_devtype.sum_dns_lookup_time </td>
<td> Total time browser waited for DNS resolution </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_devtype.sum_dom_content_load_time </td>
<td> Total time browser waited for loading document cotent </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_devtype.sum_page_download_time </td>
<td> Total time browser waited receiving data </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_devtype.sum_page_load_time </td>
<td> Total time browser waited for loading page </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_devtype.sum_redirection_time </td>
<td> Total time browser waited for redirecting </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_devtype.sum_rum_client_data_transfer_time </td>
<td> Total time to send data from start of response to the end </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_devtype.sum_server_rtt </td>
<td> Total time browser waited due to application (Avi to server) network latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_devtype.sum_service_time </td>
<td> Total time for Avi response. It measures time spent from the first packet of client  request received by Avi until the first packet of Avi's response </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_devtype.sum_waiting_time </td>
<td> Total time browser waited get first byte of response </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Rum_Country Metrics </h2>
<div class='container-fluid'>
<p>
Navigation Timings aggregated over dimension Country
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> rum_country.sum_application_response_time </td>
<td> Total time browser waited due to application (Avi to server) latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_country.sum_blocking_time </td>
<td> Total time browser was blocked from loading page </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_country.sum_browser_rendering_time </td>
<td> Total time browser waited for rendering content </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_country.sum_client_rtt </td>
<td> Total time browser waited due to client network latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_country.sum_connection_time </td>
<td> Total time browser waited for connection setup </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_country.sum_dns_lookup_time </td>
<td> Total time browser waited for DNS resolution </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_country.sum_dom_content_load_time </td>
<td> Total time browser waited for loading document cotent </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_country.sum_page_download_time </td>
<td> Total time browser waited receiving data </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_country.sum_page_load_time </td>
<td> Total time browser waited for loading page </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_country.sum_redirection_time </td>
<td> Total time browser waited for redirecting </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_country.sum_rum_client_data_transfer_time </td>
<td> Total time to send data from start of response to the end </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_country.sum_server_rtt </td>
<td> Total time browser waited due to application (Avi to server) network latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_country.sum_service_time </td>
<td> Total time for Avi response. It measures time spent from the first packet of client  request received by Avi until the first packet of Avi's response </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_country.sum_waiting_time </td>
<td> Total time browser waited get first byte of response </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Rum_Ipgroup Metrics </h2>
<div class='container-fluid'>
<p>
Navigation Timings aggregated over dimension IPGroup
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> rum_ipgroup.sum_application_response_time </td>
<td> Total time browser waited due to application (Avi to server) latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_ipgroup.sum_blocking_time </td>
<td> Total time browser was blocked from loading page </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_ipgroup.sum_browser_rendering_time </td>
<td> Total time browser waited for rendering content </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_ipgroup.sum_client_rtt </td>
<td> Total time browser waited due to client network latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_ipgroup.sum_connection_time </td>
<td> Total time browser waited for connection setup </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_ipgroup.sum_dns_lookup_time </td>
<td> Total time browser waited for DNS resolution </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_ipgroup.sum_dom_content_load_time </td>
<td> Total time browser waited for loading document cotent </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_ipgroup.sum_page_download_time </td>
<td> Total time browser waited receiving data </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_ipgroup.sum_page_load_time </td>
<td> Total time browser waited for loading page </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_ipgroup.sum_redirection_time </td>
<td> Total time browser waited for redirecting </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_ipgroup.sum_rum_client_data_transfer_time </td>
<td> Total time to send data from start of response to the end </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_ipgroup.sum_server_rtt </td>
<td> Total time browser waited due to application (Avi to server) network latency </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_ipgroup.sum_service_time </td>
<td> Total time for Avi response. It measures time spent from the first packet of client  request received by Avi until the first packet of Avi's response </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> rum_ipgroup.sum_waiting_time </td>
<td> Total time browser waited get first byte of response </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Dos Metrics </h2>
<div class='container-fluid'>
<p>
Dos Attack Metrics
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> dos.avg_attack_count </td>
<td> Rate of DOS attack per sec </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dos.sum_attack_duration </td>
<td> Duration of the Attack </td>
<td> SECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Dns_Client Metrics </h2>
<div class='container-fluid'>
<p>
VSERVER DNS metrics
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> dns_client.avg_avi_errors </td>
<td> Rate of avi errors per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_complete_queries </td>
<td> Rate of DNS responses per second. it includes errors </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_dns_query_with_edns </td>
<td> Rate of queries with EDNS resource record  per second. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_domain_lookup_failures </td>
<td> Rate of domain lookup DNS Requests per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_errored_queries </td>
<td> Rate of errored DNS responses per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_gslbpool_member_not_available </td>
<td> Rate of GSLB pool member not available per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_invalid_queries </td>
<td> Rate of invalid queries </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_local_nxdomains </td>
<td> Rate of nxdomains per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_local_responses </td>
<td> Rate of local responses from Avi (GSLB) per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_req_type_a </td>
<td> Rate of DNS Requests of type A per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_req_type_aaaa </td>
<td> Rate of DNS Requests of type AAAA per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_req_type_any </td>
<td> Rate of DNS Requests of type ANY per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_req_type_dnskey </td>
<td> Rate of DNS Requests of type DNSKEY per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_req_type_mx </td>
<td> Rate of DNS Requests of type MX per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_req_type_ns </td>
<td> Rate of DNS Requests of type NS per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_req_type_other </td>
<td> Rate of DNS Requests of type NS per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_req_type_rrsig </td>
<td> Rate of DNS Requests of type RRSIG per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_req_type_srv </td>
<td> Rate of DNS Requests of type SRV per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_req_type_txt </td>
<td> Rate of DNS Requests of type TXT per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_resp_type_a </td>
<td> Rate of DNS Responses of type A per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_resp_type_aaaa </td>
<td> Rate of DNS Requests of type AAAA per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_resp_type_cname </td>
<td> Rate of DNS Requests of type CNAME per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_resp_type_mx </td>
<td> Rate of DNS Requests of type MX per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_resp_type_ns </td>
<td> Rate of DNS Requests of type NS per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_resp_type_other </td>
<td> Rate of DNS Requests of type OTHER per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_resp_type_srv </td>
<td> Rate of DNS Requests of type SRV per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_resp_unsolicited </td>
<td> Rate of DNS Response without a request per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_tcp_passthrough_errors </td>
<td> Rate of TCP passthrough DNS errored requests per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_tcp_passthrough_queries </td>
<td> Rate of TCP passthrough DNS Requests per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_tcp_queries </td>
<td> Rate of tcp queries per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_udp_dns_response_any_to_well_known_ports </td>
<td> Rate of responses sent to well known ports for requests of type ANY, where the response size goes beyond a threshold. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_udp_dns_response_dnskey_to_well_known_ports </td>
<td> Number of responses sent to well known ports for requests of type DNSKEY, where the response size goes beyond a threshold. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_udp_dns_response_rrsig_to_well_known_ports </td>
<td> Number of responses sent to well known ports for requests of type RRSIG, where the response size goes beyond a threshold. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_udp_dns_response_size_any_to_well_known_ports </td>
<td> Bytes per second of responses sent to well known ports for requests of type ANY, where the response size goes beyond a threshold. </td>
<td> BYTES_PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_udp_dns_response_size_dnskey_to_well_known_ports </td>
<td> Bytes per second of responses sent to well known ports for requests of type DNSKEY, where the response size goes beyond a threshold. </td>
<td> BYTES_PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_udp_dns_response_size_rrsig_to_well_known_ports </td>
<td> Bytes per second of responses sent to well known ports for requests of type RRSIG, where the response size goes beyond a threshold. </td>
<td> BYTES_PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_udp_dns_response_size_txt_to_well_known_ports </td>
<td> Bytes per second of responses sent to well known ports for requests of type TXT, where the response size goes beyond a threshold. </td>
<td> BYTES_PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_udp_dns_response_txt_to_well_known_ports </td>
<td> Number of responses sent to well known ports for requests of type TXT, where the response size goes beyond a threshold. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_udp_passthrough_errors </td>
<td> Rate of UDP passthrough DNS errored requests per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_udp_passthrough_queries </td>
<td> Rate of UDP passthrough DNS Requests per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_udp_passthrough_resp_time </td>
<td> Average query response time for UDP passthrough queries </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_udp_queries </td>
<td> Rate of udp queries per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.avg_unsupported_queries </td>
<td> Rate of unsupported DNS Requests per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.pct_errored_queries </td>
<td> Percentage of errored DNS responses </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_client.sum_udp_passthrough_resp_time </td>
<td> Total duration across all connections </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Dns_Server Metrics </h2>
<div class='container-fluid'>
<p>
SERVER DNS metrics
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> dns_server.avg_complete_queries </td>
<td> Rate of DNS responses per second. it includes errors </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_server.avg_errored_queries </td>
<td> Rate of errored DNS responses per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_server.avg_req_type_a </td>
<td> Rate of DNS Requests of type A per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_server.avg_req_type_aaaa </td>
<td> Rate of DNS Requests of type AAAA per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_server.avg_resp_type_a </td>
<td> Rate of DNS Responses of type A per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_server.avg_resp_type_aaaa </td>
<td> Rate of DNS Requests of type AAAA per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_server.avg_resp_type_cname </td>
<td> Rate of DNS Requests of type CNAME per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_server.avg_resp_type_mx </td>
<td> Rate of DNS Requests of type MX per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_server.avg_resp_type_ns </td>
<td> Rate of DNS Requests of type NS per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_server.avg_resp_type_other </td>
<td> Rate of DNS Requests of type OTHER per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_server.avg_resp_type_srv </td>
<td> Rate of DNS Requests of type SRV per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_server.avg_tcp_queries </td>
<td> Rate of tcp queries per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_server.avg_udp_queries </td>
<td> Rate of udp queries per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> dns_server.pct_errored_queries </td>
<td> Percentage of errored DNS responses </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Service_Insights Metrics </h2>
<div class='container-fluid'>
<p>
Metrics for destination traffic from a VS
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> service_insights.avg_bandwidth </td>
<td> Rate of Bandwidth </td>
<td> BITS_PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> service_insights.avg_client_end2end_latency </td>
<td> Avg. client end2end latency seen by clients excluding failed responses </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> service_insights.avg_complete_conns </td>
<td> Average rate of connetions per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> service_insights.avg_complete_responses </td>
<td> Rate of complete responses including errors </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> service_insights.avg_dropped_conns </td>
<td> Average rate of dropped connections per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> service_insights.avg_error_responses </td>
<td> Rate of errors requests </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> service_insights.avg_http_timeout </td>
<td> Rate of HTTP timeouts </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> service_insights.avg_policy_drops </td>
<td> Average rate of policy-dropped connections per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> service_insights.avg_total_requests </td>
<td> Rate of requests </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> service_insights.max_open_conns </td>
<td> Maximum number of concurrent open connections </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> service_insights.sum_client_end2end_latency </td>
<td> Sum of end to end latency seen by client for URL excluding the failed responses </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Source_Insights Metrics </h2>
<div class='container-fluid'>
<p>
Metrics for source of traffic to a VS
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> source_insights.avg_bandwidth </td>
<td> Rate of Bandwidth </td>
<td> BITS_PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> source_insights.avg_client_end2end_latency </td>
<td> Avg. client end2end latency seen by clients excluding failed responses </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> source_insights.avg_complete_conns </td>
<td> Average rate of connetions per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> source_insights.avg_complete_responses </td>
<td> Rate of complete responses including errors </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> source_insights.avg_dropped_conns </td>
<td> Average rate of dropped connections per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> source_insights.avg_error_responses </td>
<td> Rate of errors requests </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> source_insights.avg_http_timeout </td>
<td> Rate of HTTP timeouts </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> source_insights.avg_policy_drops </td>
<td> Average rate of policy-dropped connections per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> source_insights.avg_total_requests </td>
<td> Rate of requests </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> source_insights.avg_waf_attacks </td>
<td> Average number of transactions per second identified by WAF as attacks. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> source_insights.avg_waf_flagged </td>
<td> Average number of transactions per second flagged by WAF. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> source_insights.avg_waf_rejected </td>
<td> Average number of transactions per second rejected by WAF. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> source_insights.max_open_conns </td>
<td> Maximum number of concurrent open connections </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> source_insights.sum_client_end2end_latency </td>
<td> Sum of end to end latency seen by client for URL excluding the failed responses </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Tenant_Stats Metrics </h2>
<div class='container-fluid'>
<p>
Tenant Metrics
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> tenant_stats.avg_num_active_vs </td>
<td> Current number of VS for the tenant </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> tenant_stats.avg_num_backend_servers </td>
<td> Current number of unique IP:port servers in use as observed by the controller </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> tenant_stats.avg_num_se_cores </td>
<td> Current number of CPU cores across all Service Engines </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> tenant_stats.avg_num_service_cores </td>
<td> Average number of service cores for the tenant </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> tenant_stats.avg_num_ses </td>
<td> Current number of SEs for the tenant </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> tenant_stats.avg_num_sockets </td>
<td> (Deprecated) Average number of SE sockets for the tenant </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> tenant_stats.avg_total_se_throughput </td>
<td> Current throughput across all Service Engines </td>
<td> BITS_PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> tenant_stats.max_be_servers_lic_usage </td>
<td> (Deprecated) Maximum backend servers usage fraction </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> tenant_stats.max_num_active_vs </td>
<td> Max number of VS for the tenant </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> tenant_stats.max_num_active_vs_lic_usage </td>
<td> Maximum number of active VS usage fraction </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> tenant_stats.max_num_backend_servers </td>
<td> Number of unique IP:port servers in use as observed by the controller </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> tenant_stats.max_num_se_cores </td>
<td> Number of CPU cores across all Service Engines </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> tenant_stats.max_num_service_cores </td>
<td> Max number of service cores for the tenant </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> tenant_stats.max_num_service_cores_usage </td>
<td> Maximum number of service cores usage fraction </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> tenant_stats.max_num_ses </td>
<td> Max number of SEs for the tenant </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> tenant_stats.max_num_ses_lic_usage </td>
<td> (Deprecated) Maximum number of SEs usage fraction </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> tenant_stats.max_num_sockets </td>
<td> (Deprecated) Max number of SE sockets for the tenant </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> tenant_stats.max_num_sockets_lic_usage </td>
<td> (Deprecated) Maximum number of SE sockets usage fraction </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> tenant_stats.max_se_cores_lic_usage </td>
<td> (Deprecated) Maximum number of SE cores usage fraction </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> tenant_stats.max_se_throughput_lic_usage </td>
<td> (Deprecated) Maximum throughput usage fraction </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> tenant_stats.max_total_se_throughput </td>
<td> Total throughput across all Service Engines </td>
<td> BITS_PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> tenant_stats.sum_total_se_bytes </td>
<td> Total bytes including ingress and egress traffic seen by the SE </td>
<td> BYTES </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> tenant_stats.sum_total_vs_bytes </td>
<td> Sum of bytes including traffic from client and to backend servers, across all VS. </td>
<td> BYTES </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> tenant_stats.sum_total_vs_client_bytes </td>
<td> Sum of bytes including traffic from client, across all VS. </td>
<td> BYTES </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> tenant_stats.sum_total_vs_usage </td>
<td> Number of hours of Virtual Service usage </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Se_If Metrics </h2>
<div class='container-fluid'>
<p>
SE Interface Metrics
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> se_if.avg_bandwidth </td>
<td> Average transmit and receive network bandwidth for an interface. </td>
<td> BITS_PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.avg_connection_table_usage </td>
<td> Connection table usage percentage. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> se_if.avg_rx_bytes </td>
<td> Average rate of received bytes on an interface. </td>
<td> BYTES_PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> se_if.avg_rx_bytes_dropped_non_vs </td>
<td> Average rate of received bytes dropped per second. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.avg_rx_pkts </td>
<td> Average rate of received packets per second. </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> se_if.avg_rx_pkts_dropped_non_vs </td>
<td> Average rate of received packets dropped per second. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.avg_syn_seen_entries_usage </td>
<td> Percentage of syn seen entries currently used for an interface. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> se_if.avg_tx_bytes </td>
<td> Average rate of transmitted bytes on an interface </td>
<td> BYTES_PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> se_if.avg_tx_pkts </td>
<td> Average rate of transmit packets per second. </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> se_if.max_peak_bandwidth </td>
<td> Maximum bandwidth observed on an interface. </td>
<td> BYTES_PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> se_if.max_rx_bytes_absolute </td>
<td> Total number of received bytes. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> se_if.max_tx_bytes_absolute </td>
<td> Total number of transmitted bytes. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_arp_rx_rl_drops </td>
<td> ARP packets dropped by rate limiter. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_connection_dropped_syn_seen_limit </td>
<td> Number of times flowtable syn seen entry limit is reached. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_connection_dropped_table_limit </td>
<td> Number of times flowtable entries limit is reached. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_flow_conn_throttled </td>
<td> Number of conn throttled due to rate limiter. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_flow_conn_throttled_mem </td>
<td> Conn throttled due to memory failure. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_flow_mac_errors </td>
<td> Number of packets where dst mac address does not correspond to interface. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_flow_parse_unknown </td>
<td> Number of received packets that are not ICMP req/resp, UDP, TCP and inter-SE messages. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_flow_pkts_throttled </td>
<td> Number of packets throttled by rate limiter. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_flow_table_num_entries </td>
<td> Number of entries in the flow table. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_flow_table_remote_entries </td>
<td> Number of flow table entries of flows punted to a secondary SE. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_flowprobe_tx_rl_drops </td>
<td> Flowprobe packets dropped by rate limiter. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_gro_mbufs_coalesced </td>
<td> Number of input packets received and coalesced in one burst from the rx queue. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_icmp_rx_rl_drops </td>
<td> Number of icmp packets dropped exceeding rate limit. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_ierrors </td>
<td> Total number of erroneous received packets. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_ip_checksum_drops </td>
<td> Total number of packets dropped at every vnic owing to a bad ip header checksum. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_kni_mbuf_alloc_failures </td>
<td> Number of times KNI mbuf pool was empty. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_kni_rx_drops </td>
<td> Number of packets dropped by KNI in the ingress path because allocation of an skb failed due to lack of available memory. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_kni_tx_drops </td>
<td> Number of packets dropped by the KNI interface in the egress path. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_kni_tx_errors </td>
<td> Number of packets dropped by the KNI interface due to transmit timeout on egress. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_l4_checksum_drops </td>
<td> Total number of packets dropped at every vnic owing to a bad tcp/udp checksum. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_local_flow_probes_req_received </td>
<td> Number of flow probe messages received by dispatcher cores. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_local_flow_probes_sent </td>
<td> Number of flow probe requests sent for open connection by the primary core. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_oerrors </td>
<td> Total number of failed packet transmission. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_rst_sent </td>
<td> Number of TCP connection resets sent. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_syn_dropped_delete_pending </td>
<td> Number of SYN packets dropped. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_tcp_rst_tx_rl_drops </td>
<td> TCP packets dropped by rate limiter. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_tx_frags_p2s </td>
<td> Number of fragments packet is fragmented into by the dispatcher when punting from primary to secondary. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> se_if.sum_tx_kni_errs </td>
<td> Mbufs were depleted in kni mbuf pool or Enqueue mbufs to kni rx queue failed during ingress. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> User_Metrics Metrics </h2>
<div class='container-fluid'>
<p>
User defined custom metrics using data-script
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> user_metrics.avg_counter </td>
<td> Time averaged value of counter over given period. For example, fetch counter 'foo' via API /api/analytics/metrics/virtualservice/?metric_id=user_metrics.avg_counter&limit=1&step=300&obj_id=foo. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> user_metrics.avg_gauge </td>
<td> Average of raw counter value of type gauge reported over given period. For example,  fetch counter 'foo' via API /api/analytics/metrics/virtualservice/?metric_id=user_metrics.avg_gauge&limit=1&step=300&obj_id=foo. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> user_metrics.max_counter </td>
<td> Maximum 'per second' reported value of counter over given period. For example, fetch counter 'foo' via API /api/analytics/metrics/virtualservice/?metric_id=user_metrics.max_counter&limit=1&step=300&obj_id=foo. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> user_metrics.max_gauge </td>
<td> Maximum raw counter value of type gauge reported over given period. For example,  fetch counter 'foo' via API /api/analytics/metrics/virtualservice/?metric_id=user_metrics.max_gauge&limit=1&step=300&obj_id=foo. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> user_metrics.min_counter </td>
<td> Minimum 'per second' reported value of counter over given period. For example, fetch counter 'foo' via API /api/analytics/metrics/virtualservice/?metric_id=user_metrics.min_counter&limit=1&step=300&obj_id=foo. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> user_metrics.min_gauge </td>
<td> Minimum raw counter value of type gauge reported over given period. For example,  fetch counter 'foo' via API /api/analytics/metrics/virtualservice/?metric_id=user_metrics.min_gauge&limit=1&step=300&obj_id=foo. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> user_metrics.sum_counter </td>
<td> Sum of raw counter value reported over given period. For example,  fetch counter 'foo' via API /api/analytics/metrics/virtualservice/?metric_id=user_metrics.sum_counter&limit=1&step=300&obj_id=foo. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> user_metrics.sum_gauge </td>
<td> (Deprecated) Sum of raw counter value of type gauge reported over given period. For example,  fetch counter 'foo' via API /api/analytics/metrics/virtualservice/?metric_id=user_metrics.sum_gauge&limit=1&step=300&obj_id=foo. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Waf_Group Metrics </h2>
<div class='container-fluid'>
<p>
WAF group specific metrics
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> waf_group.avg_evaluated </td>
<td> Time averaged value of connections per second evaluated by WAF Rule-Group. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_group.avg_flagged </td>
<td> Time averaged value of connections per second flagged by WAF Rule-Group. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_group.avg_matched </td>
<td> Time averaged value of connections per second matched WAF Rule-Group. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_group.avg_rejected </td>
<td> Time averaged value of connections per second rejected by WAF Rule-Group. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_group.max_evaluated </td>
<td> Maximum value of connections per second evaluated by WAF Rule-Group. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_group.max_flagged </td>
<td> Maximum value of connections per second flagged by WAF Rule-Group. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_group.max_matched </td>
<td> Maximum value of connections per second matched  WAF Rule-Group. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_group.max_rejected </td>
<td> Maximum value of connections per second rejected by WAF Rule-Group. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_group.sum_evaluated </td>
<td> Total number of connections evaluated by WAF Rule-Group. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_group.sum_flagged </td>
<td> Total number of connections flagged by WAF Rule-Group. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_group.sum_matched </td>
<td> Total number of connections matched by WAF Rule-Group. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_group.sum_rejected </td>
<td> Total number of connections rejected by WAF Rule-Group. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Waf_Tag Metrics </h2>
<div class='container-fluid'>
<p>
WAF tag specific metrics
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> waf_tag.avg_flagged </td>
<td> Time averaged value of connections per second flagged as attack by any rule with WAF Tag. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_tag.avg_matched </td>
<td> Time averaged value of connections per second matched any rule with WAF Tag. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_tag.avg_rejected </td>
<td> Time averaged value of connections per second rejected by any rule with WAF Tag. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_tag.max_flagged </td>
<td> Maximum value of connections per second flagged as attach by any rule with WAF Tag. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_tag.max_matched </td>
<td> Maximum value of connections per second matched any rule with WAF Tag. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_tag.max_rejected </td>
<td> Maximum value of connections per second rejected by any rule with WAF Tag. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_tag.sum_flagged </td>
<td> Total number of connections flagged as attack by any rule with WAF Tag. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_tag.sum_matched </td>
<td> Total number of connections matched any rule with WAF Tag. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_tag.sum_rejected </td>
<td> Total number of connections rejected by any rule with WAF Tag. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Waf_Rule Metrics </h2>
<div class='container-fluid'>
<p>
WAF rule specific metrics
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> waf_rule.avg_evaluated </td>
<td> Time averaged value of connections per second evaluated by WAF Rule. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_rule.avg_flagged </td>
<td> Time averaged value of connections per second flagged as attack by WAF Rule. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_rule.avg_matched </td>
<td> Time averaged value of connections per second matched WAF Rule. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_rule.avg_rejected </td>
<td> Time averaged value of connections per second rejected by WAF Rule. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_rule.max_evaluated </td>
<td> Maximum value of connections per second evaluated by WAF Rule. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_rule.max_flagged </td>
<td> Maximum value of connections per second flagged as attack by WAF Rule. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_rule.max_matched </td>
<td> Max value of connections per second matched WAF Rule. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_rule.max_rejected </td>
<td> Maximum value of connections per second rejected by WAF Rule. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_rule.sum_evaluated </td>
<td> Total number of connections evaluated by WAF Rule. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_rule.sum_flagged </td>
<td> Total number of connections flagged as attack by WAF Rule. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_rule.sum_matched </td>
<td> Total number of connections matched by WAF Rule. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_rule.sum_rejected </td>
<td> Total number of connections rejected by WAF Rule. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Process_Stats Metrics </h2>
<div class='container-fluid'>
<p>
stats for processes running on controller
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> process_stats.avg_ctx_switches_invol </td>
<td> Average number of involuntary context switches per second. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> process_stats.avg_ctx_switches_vol </td>
<td> Average number of voluntary  context switches per second. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> process_stats.avg_fds </td>
<td> Number of file descriptors currently opened by this process. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> process_stats.avg_io_read_bytes </td>
<td> Average per second number of io bytes read by process. </td>
<td> BYTES_PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> process_stats.avg_io_read_count </td>
<td> Average number of io reads by process per second. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> process_stats.avg_io_write_bytes </td>
<td> Average per second io bytes writes by process. </td>
<td> BYTES_PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> process_stats.avg_io_write_count </td>
<td> Average per second number of io writes by process. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> process_stats.avg_num_threads </td>
<td> Average number of threads currently used by this process. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> process_stats.avg_pss </td>
<td> Average memory (in Kilo bytes) shared with other processes. </td>
<td> KILO_BYTES </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> process_stats.avg_rss </td>
<td> Average Resident Set Size (aka non-swapped physical memory which process is using). </td>
<td> KILO_BYTES </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> process_stats.avg_swap </td>
<td> Average Amount of memory that has been swapped out to disk. </td>
<td> KILO_BYTES </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> process_stats.avg_vms </td>
<td> Average Virtual Memory Size (aka total virtual memory which process is using). </td>
<td> KILO_BYTES </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> process_stats.max_cpu_pct </td>
<td> Maximum cpu usage by this process. </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> process_stats.max_pss </td>
<td> Max memory (in Kilo bytes) shared with other processes. </td>
<td> KILO_BYTES </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Http2_Client Metrics </h2>
<div class='container-fluid'>
<p>
Http Ver 2 Client metrics
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> http2_client.avg_complete_responses </td>
<td> Rate of HTTP2 responses sent per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG, HOLTWINTERS_AT_AS </td>
<td> False </td>
</tr>
<tr>
<td> http2_client.avg_error_responses </td>
<td> Rate of HTTP2 error responses sent per second. It does not include errors excluded in analytics profile </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> http2_client.avg_errors_excluded </td>
<td> Rate of HTTP2 responses excluded as errors based on analytics profile </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> http2_client.avg_resp_1xx </td>
<td> Rate of 1xx HTTP2 responses sent per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> http2_client.avg_resp_2xx </td>
<td> Rate of 2xx HTTP2 responses sent per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> http2_client.avg_resp_3xx </td>
<td> Rate of 3xx HTTP2 responses sent per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> http2_client.avg_resp_4xx </td>
<td> Rate of HTTP2 4xx responses sent per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> http2_client.avg_resp_4xx_avi_errors </td>
<td> Rate of HTTP2 4xx responses as errors sent by Avi Vantage. It does not include any error codes excluded in the analytics profile and pool server errors </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> http2_client.avg_resp_5xx </td>
<td> Rate of 5xx HTTP2 responses sent per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> http2_client.avg_resp_5xx_avi_errors </td>
<td> Rate of HTTP2 5xx responses as errors sent by Avi Vantage. It does not include any error codes excluded in the analytics profile and pool server errors </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> http2_client.avg_total_requests </td>
<td> Average rate of client HTTP2 requests received by the virtual service per second </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> http2_client.pct_response_errors </td>
<td> Percent of HTTP2 4xx and 5xx responses. It doesn't include errors excluded in analytics profile </td>
<td> PERCENT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> http2_client.sum_get_reqs </td>
<td> Total number of HTTP2 GET requests </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> http2_client.sum_other_reqs </td>
<td> Total number of HTTP2 requests that are not GET or POST requests </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> http2_client.sum_post_reqs </td>
<td> Total number of HTTP2 POST requests </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> http2_client.sum_resp_1xx </td>
<td> Total number of HTTP2 1XX responses </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> http2_client.sum_resp_2xx </td>
<td> Total number of HTTP2 2XX responses </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> http2_client.sum_resp_3xx </td>
<td> Total number of HTTP2 3XX responses </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> http2_client.sum_resp_4xx </td>
<td> Total number of HTTP2 4XX error responses </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> http2_client.sum_resp_5xx </td>
<td> Total number of HTTP2 5XX error responses </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Waf_Allowlist Metrics </h2>
<div class='container-fluid'>
<p>
WAF whitelist rule specific metrics
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> waf_allowlist.sum_action_allow </td>
<td> Total number of requests where WAF whitelist allow action got executed. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_allowlist.sum_action_bypass </td>
<td> Total number of requests processed with WAF allowlist action as bypass. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_allowlist.sum_action_continue </td>
<td> Total number of requests processed with WAF allowlist action as run in detection mode. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_allowlist.sum_action_detection_mode </td>
<td> Total number of requests processed with WAF allowlist action as continue. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_allowlist.sum_evaluated </td>
<td> Total number of requests evaluated by a WAF whitelist rule. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_allowlist.sum_matched </td>
<td> Total number of requests matched by a WAF whitelist rule. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Waf_Psmgroup Metrics </h2>
<div class='container-fluid'>
<p>
WAF PSM group specific metrics
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> waf_psmgroup.sum_allowed_match_elements </td>
<td> Total number of requests with matched_elements marked as valid by a WAF PSM group. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_psmgroup.sum_evaluated </td>
<td> Total number of requests evaluated by a WAF PSM group. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_psmgroup.sum_flagged </td>
<td> Total number of requests flagged by a WAF PSM group. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_psmgroup.sum_rejected </td>
<td> Total number of requests rejected by a WAF PSM group. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Waf_Psmlocation Metrics </h2>
<div class='container-fluid'>
<p>
WAF PSM location specific metrics
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> waf_psmlocation.sum_matched </td>
<td> Total number of requests matched by a WAF PSM location. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Waf_Psmrule Metrics </h2>
<div class='container-fluid'>
<p>
WAF PSM rule specific metrics
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> waf_psmrule.sum_evaluated </td>
<td> Total number of requests evaluated by a WAF PSM rule. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_psmrule.sum_hit_actions </td>
<td> Total number of requests where at least one WAF PSM rule match_element matched the value. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_psmrule.sum_matched </td>
<td> Total number of requests with at least one present match_element a WAF PSM rule. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> waf_psmrule.sum_miss_actions </td>
<td> Total number of requests where at least one WAF PSM rule match_element did not match the value. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Gslb_Stats Metrics </h2>
<div class='container-fluid'>
<p>
Stats for GSLB.
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> gslb_stats.avg_errored_queue_size </td>
<td> Average size of the errrored  queue per site. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> gslb_stats.avg_pending_requests_size </td>
<td> Average size of the pending request queue per site. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> gslb_stats.avg_replication_queue_size </td>
<td> Average size of the replication queue per site. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Vs_Scaleout_Stats Metrics </h2>
<div class='container-fluid'>
<p>
Virtualservice Scaleout Stats.
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> vs_scaleout_stats.sum_flow_created_by_probe_rsp </td>
<td> Number of Flow Entries created on local SE after receiving flow probe response from a remote SE. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> vs_scaleout_stats.sum_flow_probe_rqs_discard_miss </td>
<td> Number of Flow Probe requests discarded due to flow-lookup miss. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> vs_scaleout_stats.sum_flow_probe_rqs_discard_non_local </td>
<td> Number of Flow Probe requests discarded as flow-entry was remote. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> vs_scaleout_stats.sum_flow_probe_rqs_rcvd </td>
<td> Number of Flow Probe requests received from remote SE. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> vs_scaleout_stats.sum_flow_probe_rqs_sent </td>
<td> Number of Flow Probe requests sent to remote SE. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> vs_scaleout_stats.sum_flow_probe_rsps_rcvd </td>
<td> Number of Flow Probe responses received from remote SE. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> vs_scaleout_stats.sum_flow_probe_rsps_sent </td>
<td> Number of Flow Probe responses sent to remote SE. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> vs_scaleout_stats.sum_num_vs_pkts_punted </td>
<td> Number of VS packets punted to remote SE's. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> vs_scaleout_stats.sum_num_vs_pkts_tunneled_back </td>
<td> Number of VS packets tunneled back to all remote SE's. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> vs_scaleout_stats.sum_vs_flows_local </td>
<td> Number of locally terminated VS flows. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> vs_scaleout_stats.sum_vs_flows_remote </td>
<td> Number of VS flows punted to remote SE. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Api_Perf_Stats Metrics </h2>
<div class='container-fluid'>
<p>
Stats for all aviportal requests exceeding api_perf threshold.
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> api_perf_stats.avg__add_joined_data </td>
<td> Average time taken to execute _add_joined_data per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__check_privilege_in_policy </td>
<td> Average time taken to execute _check_privilege_in_policy per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__check_privilege_in_role </td>
<td> Average time taken to execute _check_privilege_in_role per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__delete </td>
<td> Average time taken to execute _delete per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__exception_hdlr </td>
<td> Average time taken to execute _exception_hdlr per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__fqdn_must_check </td>
<td> Average time taken to execute _fqdn_must_check per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__get_object_from_ref </td>
<td> Average time taken to execute _get_object_from_ref per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__get_pool_data </td>
<td> Average time taken to execute _get_pool_data per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__gs_hdlr </td>
<td> Average time taken to execute _gs_hdlr per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__gslb_check_tenant </td>
<td> Average time taken to execute _gslb_check_tenant per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__init_model_serializer </td>
<td> Average time taken to execute _init_model_serializer per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__ipam_dns_delete_vip </td>
<td> Average time taken to execute _ipam_dns_delete_vip per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__ipam_dns_update_vip </td>
<td> Average time taken to execute _ipam_dns_update_vip per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__manual_serialize_obj </td>
<td> Average time taken to execute _manual_serialize_obj per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__obj_del_hdlr </td>
<td> Average time taken to execute _obj_del_hdlr per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__obj_hdlr </td>
<td> Average time taken to execute _obj_hdlr per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__pbs_for_backend_ops </td>
<td> Average time taken to execute _pbs_for_backend_ops per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__post_decl_hdlr </td>
<td> Average time taken to execute _post_decl_hdlr per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__post_decl_obj_hdlr </td>
<td> Average time taken to execute _post_decl_obj_hdlr per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__pre_decl_hdlr </td>
<td> Average time taken to execute _pre_decl_hdlr per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__send_logorc_create </td>
<td> Average time taken to execute _send_logorc_create per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__send_logorc_delete </td>
<td> Average time taken to execute _send_logorc_delete per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__server_state_db_cache </td>
<td> Average time taken to execute _server_state_db_cache per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__update </td>
<td> Average time taken to execute _update per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__update_pools </td>
<td> Average time taken to execute _update_pools per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__vs_state_db_cache </td>
<td> Average time taken to execute _vs_state_db_cache per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg__xlate_glb </td>
<td> Average time taken to execute _xlate_glb per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_callback </td>
<td> Average time taken to execute callback per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_callback_custom_post </td>
<td> Average time taken to execute callback_custom_post per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_callback_custom_pre </td>
<td> Average time taken to execute callback_custom_pre per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_application_profile </td>
<td> Average time taken to execute check_application_profile per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_client_auth </td>
<td> Average time taken to execute check_client_auth per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_cloud </td>
<td> Average time taken to execute check_cloud per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_content_rewrite </td>
<td> Average time taken to execute check_content_rewrite per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_debug_for_children </td>
<td> Average time taken to execute check_debug_for_children per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_delete_permission </td>
<td> Average time taken to execute check_delete_permission per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_dns_policies </td>
<td> Average time taken to execute check_dns_policies per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_east_west_placement </td>
<td> Average time taken to execute check_east_west_placement per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_http_policies </td>
<td> Average time taken to execute check_http_policies per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_l4_policies </td>
<td> Average time taken to execute check_l4_policies per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_legacy_ha_flow_mirror_tcp_fast </td>
<td> Average time taken to execute check_legacy_ha_flow_mirror_tcp_fast per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_network_profile </td>
<td> Average time taken to execute check_network_profile per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_network_security_policy </td>
<td> Average time taken to execute check_network_security_policy per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_network_service </td>
<td> Average time taken to execute check_network_service per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_pool_groups </td>
<td> Average time taken to execute check_pool_groups per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_pools </td>
<td> Average time taken to execute check_pools per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_properties </td>
<td> Average time taken to execute check_properties per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_se_group </td>
<td> Average time taken to execute check_se_group per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_security_policy </td>
<td> Average time taken to execute check_security_policy per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_server_network_profile </td>
<td> Average time taken to execute check_server_network_profile per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_service_pool_reference </td>
<td> Average time taken to execute check_service_pool_reference per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_service_pool_select </td>
<td> Average time taken to execute check_service_pool_select per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_service_poolgroup_reference </td>
<td> Average time taken to execute check_service_poolgroup_reference per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_services_and_virtual_host </td>
<td> Average time taken to execute check_services_and_virtual_host per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_services_network_properties </td>
<td> Average time taken to execute check_services_network_properties per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_snat_ip </td>
<td> Average time taken to execute check_snat_ip per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_snat_vsvip_overlap </td>
<td> Average time taken to execute check_snat_vsvip_overlap per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_ssl_and_certificates </td>
<td> Average time taken to execute check_ssl_and_certificates per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_ssl_profile_selectors </td>
<td> Average time taken to execute check_ssl_profile_selectors per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_sso </td>
<td> Average time taken to execute check_sso per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_tenant </td>
<td> Average time taken to execute check_tenant per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_tenant_resource_access </td>
<td> Average time taken to execute check_tenant_resource_access per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_update_type </td>
<td> Average time taken to execute check_update_type per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_use_vip_as_snat </td>
<td> Average time taken to execute check_use_vip_as_snat per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_user </td>
<td> Average time taken to execute check_user per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_user_tenant_resource </td>
<td> Average time taken to execute check_user_tenant_resource per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_vip_and_network_profile </td>
<td> Average time taken to execute check_vip_and_network_profile per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_vrf_context </td>
<td> Average time taken to execute check_vrf_context per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_vs_datascripts </td>
<td> Average time taken to execute check_vs_datascripts per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_vses_sharing_pool </td>
<td> Average time taken to execute check_vses_sharing_pool per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_vsvip </td>
<td> Average time taken to execute check_vsvip per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_check_waf_policy </td>
<td> Average time taken to execute check_waf_policy per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_clean_cached_data </td>
<td> Average time taken to execute clean_cached_data per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_collate_files </td>
<td> Average time taken to execute collate_files per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_convert_json_patch_to_put </td>
<td> Average time taken to execute convert_json_patch_to_put per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_create </td>
<td> Average time taken to execute create per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_create_applicationpersistenceprofile </td>
<td> Average time taken to execute create_applicationpersistenceprofile per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_create_debugvirtualservice </td>
<td> Average time taken to execute create_debugvirtualservice per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_create_gslb </td>
<td> Average time taken to execute create_gslb per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_create_gslbgeodbprofile </td>
<td> Average time taken to execute create_gslbgeodbprofile per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_create_gslbservice </td>
<td> Average time taken to execute create_gslbservice per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_create_healthmonitor </td>
<td> Average time taken to execute create_healthmonitor per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_create_pkiprofile </td>
<td> Average time taken to execute create_pkiprofile per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_custom_get </td>
<td> Average time taken to execute custom_get per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_custom_post_save </td>
<td> Average time taken to execute custom_post_save per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_custom_pre_save </td>
<td> Average time taken to execute custom_pre_save per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_custom_rollback </td>
<td> Average time taken to execute custom_rollback per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_db_cache_delete </td>
<td> Average time taken to execute db_cache_delete per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_db_cache_save </td>
<td> Average time taken to execute db_cache_save per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_delete_applicationpersistenceprofile </td>
<td> Average time taken to execute delete_applicationpersistenceprofile per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_delete_gslb </td>
<td> Average time taken to execute delete_gslb per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_delete_gslbgeodbprofile </td>
<td> Average time taken to execute delete_gslbgeodbprofile per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_delete_gslbservice </td>
<td> Average time taken to execute delete_gslbservice per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_delete_healthmonitor </td>
<td> Average time taken to execute delete_healthmonitor per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_delete_pkiprofile </td>
<td> Average time taken to execute delete_pkiprofile per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_destroy </td>
<td> Average time taken to execute destroy per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_do_post_action </td>
<td> Average time taken to execute do_post_action per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_do_put_action </td>
<td> Average time taken to execute do_put_action per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_generate_config_log </td>
<td> Average time taken to execute generate_config_log per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_get </td>
<td> Average time taken to execute get per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_get_alert_data </td>
<td> Average time taken to execute get_alert_data per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_get_collection_healthscore </td>
<td> Average time taken to execute get_collection_healthscore per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_get_debug_trace_status </td>
<td> Average time taken to execute get_debug_trace_status per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_get_faults </td>
<td> Average time taken to execute get_faults per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_get_metric_data </td>
<td> Average time taken to execute get_metric_data per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_get_object </td>
<td> Average time taken to execute get_object per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_get_object_for_update </td>
<td> Average time taken to execute get_object_for_update per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_get_pool_data </td>
<td> Average time taken to execute get_pool_data per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_get_queryset </td>
<td> Average time taken to execute get_queryset per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_get_queryset_for_update </td>
<td> Average time taken to execute get_queryset_for_update per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_get_queryset_from_policy </td>
<td> Average time taken to execute get_queryset_from_policy per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_get_queryset_from_role </td>
<td> Average time taken to execute get_queryset_from_role per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_get_runtime_data_json </td>
<td> Average time taken to execute get_runtime_data_json per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_get_scaleoutin_faults </td>
<td> Average time taken to execute get_scaleoutin_faults per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_get_se_data </td>
<td> Average time taken to execute get_se_data per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_get_server_faults </td>
<td> Average time taken to execute get_server_faults per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_get_ssl_cert_data </td>
<td> Average time taken to execute get_ssl_cert_data per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_get_ssl_cert_expiry_faults </td>
<td> Average time taken to execute get_ssl_cert_expiry_faults per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_get_view_data </td>
<td> Average time taken to execute get_view_data per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_get_vs_sdb_obj </td>
<td> Average time taken to execute get_vs_sdb_obj per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_join </td>
<td> Average time taken to execute join per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_join_list </td>
<td> Average time taken to execute join_list per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_join_subresources </td>
<td> Average time taken to execute join_subresources per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_join_subresources_list </td>
<td> Average time taken to execute join_subresources_list per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_list </td>
<td> Average time taken to execute list per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_migrate_version </td>
<td> Average time taken to execute migrate_version per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_move_uploaded_file </td>
<td> Average time taken to execute move_uploaded_file per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_patch_data_to_pb </td>
<td> Average time taken to execute patch_data_to_pb per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_pbs_send_via_batched_mode </td>
<td> Average time taken to execute pbs_send_via_batched_mode per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_pbs_send_via_view_list </td>
<td> Average time taken to execute pbs_send_via_view_list per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_pre_check </td>
<td> Average time taken to execute pre_check per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_pre_save_transform </td>
<td> Average time taken to execute pre_save_transform per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_retrieve </td>
<td> Average time taken to execute retrieve per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_reverse_migrate_version </td>
<td> Average time taken to execute reverse_migrate_version per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_run_callback </td>
<td> Average time taken to execute run_callback per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_save_callback </td>
<td> Average time taken to execute save_callback per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_save_diff </td>
<td> Average time taken to execute save_diff per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_semantic_check </td>
<td> Average time taken to execute semantic_check per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_serializer_is_valid </td>
<td> Average time taken to execute serializer_is_valid per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_serializer_save </td>
<td> Average time taken to execute serializer_save per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_total_time </td>
<td> Average time taken by requests to portals. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_update </td>
<td> Average time taken to execute update per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_update_applicationpersistenceprofile </td>
<td> Average time taken to execute update_applicationpersistenceprofile per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_update_gslb </td>
<td> Average time taken to execute update_gslb per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_update_gslbgeodbprofile </td>
<td> Average time taken to execute update_gslbgeodbprofile per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_update_gslbservice </td>
<td> Average time taken to execute update_gslbservice per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_update_healthmonitor </td>
<td> Average time taken to execute update_healthmonitor per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_update_pkiprofile </td>
<td> Average time taken to execute update_pkiprofile per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.avg_update_realtime_serialized_fields </td>
<td> Average time taken to execute update_realtime_serialized_fields per request. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__add_joined_data </td>
<td> Sum of time taken to execute _add_joined_data. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__check_privilege_in_policy </td>
<td> Sum of time taken to execute _check_privilege_in_policy. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__check_privilege_in_role </td>
<td> Sum of time taken to execute _check_privilege_in_role. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__delete </td>
<td> Sum of time taken to execute _delete. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__exception_hdlr </td>
<td> Sum of time taken to execute _exception_hdlr. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__fqdn_must_check </td>
<td> Sum of time taken to execute _fqdn_must_check. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__get_object_from_ref </td>
<td> Sum of time taken to execute _get_object_from_ref. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__get_pool_data </td>
<td> Sum of time taken to execute _get_pool_data. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__gs_hdlr </td>
<td> Sum of time taken to execute _gs_hdlr. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__gslb_check_tenant </td>
<td> Sum of time taken to execute _gslb_check_tenant. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__init_model_serializer </td>
<td> Sum of time taken to execute _init_model_serializer. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__ipam_dns_delete_vip </td>
<td> Sum of time taken to execute _ipam_dns_delete_vip. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__ipam_dns_update_vip </td>
<td> Sum of time taken to execute _ipam_dns_update_vip. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__manual_serialize_obj </td>
<td> Sum of time taken to execute _manual_serialize_obj. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__obj_del_hdlr </td>
<td> Sum of time taken to execute _obj_del_hdlr. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__obj_hdlr </td>
<td> Sum of time taken to execute _obj_hdlr. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__pbs_for_backend_ops </td>
<td> Sum of time taken to execute _pbs_for_backend_ops. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__post_decl_hdlr </td>
<td> Sum of time taken to execute _post_decl_hdlr. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__post_decl_obj_hdlr </td>
<td> Sum of time taken to execute _post_decl_obj_hdlr. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__pre_decl_hdlr </td>
<td> Sum of time taken to execute _pre_decl_hdlr. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__send_logorc_create </td>
<td> Sum of time taken to execute _send_logorc_create. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__send_logorc_delete </td>
<td> Sum of time taken to execute _send_logorc_delete. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__server_state_db_cache </td>
<td> Sum of time taken to execute _server_state_db_cache. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__update </td>
<td> Sum of time taken to execute _update. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__update_pools </td>
<td> Sum of time taken to execute _update_pools. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__vs_state_db_cache </td>
<td> Sum of time taken to execute _vs_state_db_cache. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum__xlate_glb </td>
<td> Sum of time taken to execute _xlate_glb. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_callback </td>
<td> Sum of time taken to execute callback. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_callback_custom_post </td>
<td> Sum of time taken to execute callback_custom_post. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_callback_custom_pre </td>
<td> Sum of time taken to execute callback_custom_pre. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_application_profile </td>
<td> Sum of time taken to execute check_application_profile. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_client_auth </td>
<td> Sum of time taken to execute check_client_auth. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_cloud </td>
<td> Sum of time taken to execute check_cloud. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_content_rewrite </td>
<td> Sum of time taken to execute check_content_rewrite. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_debug_for_children </td>
<td> Sum of time taken to execute check_debug_for_children. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_delete_permission </td>
<td> Sum of time taken to execute check_delete_permission. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_dns_policies </td>
<td> Sum of time taken to execute check_dns_policies. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_east_west_placement </td>
<td> Sum of time taken to execute check_east_west_placement. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_http_policies </td>
<td> Sum of time taken to execute check_http_policies. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_l4_policies </td>
<td> Sum of time taken to execute check_l4_policies. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_legacy_ha_flow_mirror_tcp_fast </td>
<td> Sum of time taken to execute check_legacy_ha_flow_mirror_tcp_fast. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_network_profile </td>
<td> Sum of time taken to execute check_network_profile. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_network_security_policy </td>
<td> Sum of time taken to execute check_network_security_policy. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_network_service </td>
<td> Sum of time taken to execute check_network_service. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_pool_groups </td>
<td> Sum of time taken to execute check_pool_groups. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_pools </td>
<td> Sum of time taken to execute check_pools. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_properties </td>
<td> Sum of time taken to execute check_properties. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_se_group </td>
<td> Sum of time taken to execute check_se_group. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_security_policy </td>
<td> Sum of time taken to execute check_security_policy. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_server_network_profile </td>
<td> Sum of time taken to execute check_server_network_profile. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_service_pool_reference </td>
<td> Sum of time taken to execute check_service_pool_reference. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_service_pool_select </td>
<td> Sum of time taken to execute check_service_pool_select. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_service_poolgroup_reference </td>
<td> Sum of time taken to execute check_service_poolgroup_reference. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_services_and_virtual_host </td>
<td> Sum of time taken to execute check_services_and_virtual_host. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_services_network_properties </td>
<td> Sum of time taken to execute check_services_network_properties. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_snat_ip </td>
<td> Sum of time taken to execute check_snat_ip. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_snat_vsvip_overlap </td>
<td> Sum of time taken to execute check_snat_vsvip_overlap. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_ssl_and_certificates </td>
<td> Sum of time taken to execute check_ssl_and_certificates. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_ssl_profile_selectors </td>
<td> Sum of time taken to execute check_ssl_profile_selectors. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_sso </td>
<td> Sum of time taken to execute check_sso. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_tenant </td>
<td> Sum of time taken to execute check_tenant. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_tenant_resource_access </td>
<td> Sum of time taken to execute check_tenant_resource_access. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_update_type </td>
<td> Sum of time taken to execute check_update_type. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_use_vip_as_snat </td>
<td> Sum of time taken to execute check_use_vip_as_snat. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_user </td>
<td> Sum of time taken to execute check_user. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_user_tenant_resource </td>
<td> Sum of time taken to execute check_user_tenant_resource. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_vip_and_network_profile </td>
<td> Sum of time taken to execute check_vip_and_network_profile. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_vrf_context </td>
<td> Sum of time taken to execute check_vrf_context. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_vs_datascripts </td>
<td> Sum of time taken to execute check_vs_datascripts. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_vses_sharing_pool </td>
<td> Sum of time taken to execute check_vses_sharing_pool. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_vsvip </td>
<td> Sum of time taken to execute check_vsvip. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_check_waf_policy </td>
<td> Sum of time taken to execute check_waf_policy. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_clean_cached_data </td>
<td> Sum of time taken to execute clean_cached_data. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_collate_files </td>
<td> Sum of time taken to execute collate_files. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_convert_json_patch_to_put </td>
<td> Sum of time taken to execute convert_json_patch_to_put. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_create </td>
<td> Sum of time taken to execute create. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_create_applicationpersistenceprofile </td>
<td> Sum of time taken to execute create_applicationpersistenceprofile. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_create_debugvirtualservice </td>
<td> Sum of time taken to execute create_debugvirtualservice. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_create_gslb </td>
<td> Sum of time taken to execute create_gslb. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_create_gslbgeodbprofile </td>
<td> Sum of time taken to execute create_gslbgeodbprofile. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_create_gslbservice </td>
<td> Sum of time taken to execute create_gslbservice. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_create_healthmonitor </td>
<td> Sum of time taken to execute create_healthmonitor. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_create_pkiprofile </td>
<td> Sum of time taken to execute create_pkiprofile. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_custom_get </td>
<td> Sum of time taken to execute custom_get. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_custom_post_save </td>
<td> Sum of time taken to execute custom_post_save. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_custom_pre_save </td>
<td> Sum of time taken to execute custom_pre_save. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_custom_rollback </td>
<td> Sum of time taken to execute custom_rollback. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_db_cache_delete </td>
<td> Sum of time taken to execute db_cache_delete. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_db_cache_save </td>
<td> Sum of time taken to execute db_cache_save. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_delete_applicationpersistenceprofile </td>
<td> Sum of time taken to execute delete_applicationpersistenceprofile. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_delete_gslb </td>
<td> Sum of time taken to execute delete_gslb. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_delete_gslbgeodbprofile </td>
<td> Sum of time taken to execute delete_gslbgeodbprofile. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_delete_gslbservice </td>
<td> Sum of time taken to execute delete_gslbservice. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_delete_healthmonitor </td>
<td> Sum of time taken to execute delete_healthmonitor. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_delete_pkiprofile </td>
<td> Sum of time taken to execute delete_pkiprofile. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_destroy </td>
<td> Sum of time taken to execute destroy. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_do_post_action </td>
<td> Sum of time taken to execute do_post_action. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_do_put_action </td>
<td> Sum of time taken to execute do_put_action. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_generate_config_log </td>
<td> Sum of time taken to execute generate_config_log. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_get </td>
<td> Sum of time taken to execute get. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_get_alert_data </td>
<td> Sum of time taken to execute get_alert_data. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_get_collection_healthscore </td>
<td> Sum of time taken to execute get_collection_healthscore. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_get_debug_trace_status </td>
<td> Sum of time taken to execute get_debug_trace_status. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_get_faults </td>
<td> Sum of time taken to execute get_faults. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_get_metric_data </td>
<td> Sum of time taken to execute get_metric_data. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_get_object </td>
<td> Sum of time taken to execute get_object. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_get_object_for_update </td>
<td> Sum of time taken to execute get_object_for_update. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_get_pool_data </td>
<td> Sum of time taken to execute get_pool_data. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_get_queryset </td>
<td> Sum of time taken to execute get_queryset. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_get_queryset_for_update </td>
<td> Sum of time taken to execute get_queryset_for_update. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_get_queryset_from_policy </td>
<td> Sum of time taken to execute get_queryset_from_policy. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_get_queryset_from_role </td>
<td> Sum of time taken to execute get_queryset_from_role. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_get_runtime_data_json </td>
<td> Sum of time taken to execute get_runtime_data_json. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_get_scaleoutin_faults </td>
<td> Sum of time taken to execute get_scaleoutin_faults. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_get_se_data </td>
<td> Sum of time taken to execute get_se_data. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_get_server_faults </td>
<td> Sum of time taken to execute get_server_faults. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_get_ssl_cert_data </td>
<td> Sum of time taken to execute get_ssl_cert_data. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_get_ssl_cert_expiry_faults </td>
<td> Sum of time taken to execute get_ssl_cert_expiry_faults. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_get_view_data </td>
<td> Sum of time taken to execute get_view_data. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_get_vs_sdb_obj </td>
<td> Sum of time taken to execute get_vs_sdb_obj. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_join </td>
<td> Sum of time taken to execute join. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_join_list </td>
<td> Sum of time taken to execute join_list. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_join_subresources </td>
<td> Sum of time taken to execute join_subresources. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_join_subresources_list </td>
<td> Sum of time taken to execute join_subresources_list. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_list </td>
<td> Sum of time taken to execute list. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_migrate_version </td>
<td> Sum of time taken to execute migrate_version. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_move_uploaded_file </td>
<td> Sum of time taken to execute move_uploaded_file. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_num_2xx_status_codes </td>
<td> Number of requests that returned 2xx status codes. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_num_4xx_status_codes </td>
<td> Number of requests that returned 4xx status codes. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_num_5xx_status_codes </td>
<td> Number of requests that returned 5xx status codes. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_num_requests </td>
<td> Total number of requests made to portals in the interval. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_patch_data_to_pb </td>
<td> Sum of time taken to execute patch_data_to_pb. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_pbs_send_via_batched_mode </td>
<td> Sum of time taken to execute pbs_send_via_batched_mode. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_pbs_send_via_view_list </td>
<td> Sum of time taken to execute pbs_send_via_view_list. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_pre_check </td>
<td> Sum of time taken to execute pre_check. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_pre_save_transform </td>
<td> Sum of time taken to execute pre_save_transform. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_retrieve </td>
<td> Sum of time taken to execute retrieve. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_reverse_migrate_version </td>
<td> Sum of time taken to execute reverse_migrate_version. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_run_callback </td>
<td> Sum of time taken to execute run_callback. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_save_callback </td>
<td> Sum of time taken to execute save_callback. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_save_diff </td>
<td> Sum of time taken to execute save_diff. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_semantic_check </td>
<td> Sum of time taken to execute semantic_check. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_serializer_is_valid </td>
<td> Sum of time taken to execute serializer_is_valid. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_serializer_save </td>
<td> Sum of time taken to execute serializer_save. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_total_time </td>
<td> Sum of total time taken for all requests made to portals in interval. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_update </td>
<td> Sum of time taken to execute update. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_update_applicationpersistenceprofile </td>
<td> Sum of time taken to execute update_applicationpersistenceprofile. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_update_gslb </td>
<td> Sum of time taken to execute update_gslb. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_update_gslbgeodbprofile </td>
<td> Sum of time taken to execute update_gslbgeodbprofile. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_update_gslbservice </td>
<td> Sum of time taken to execute update_gslbservice. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_update_healthmonitor </td>
<td> Sum of time taken to execute update_healthmonitor. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_update_pkiprofile </td>
<td> Sum of time taken to execute update_pkiprofile. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> api_perf_stats.sum_update_realtime_serialized_fields </td>
<td> Sum of time taken to execute update_realtime_serialized_fields. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Nsxt_Stats Metrics </h2>
<div class='container-fluid'>
<p>
Stats for Nsxt cloud.
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> nsxt_stats.avg_api_response_time </td>
<td> Average api response time per API call. </td>
<td> MILLISECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> nsxt_stats.avg_errors </td>
<td> Average errors over period of time. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> nsxt_stats.avg_requests </td>
<td> Average requests over period of time. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> nsxt_stats.sum_api_response_time </td>
<td> Total duration across all requests. </td>
<td> MILLISECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> nsxt_stats.sum_requests </td>
<td> Total requests. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Icap_Stats Metrics </h2>
<div class='container-fluid'>
<p>
Stats for ICAP server.
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> icap_stats.avg_blocked </td>
<td> Rate of blocked ICAP responses. </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> icap_stats.avg_duration </td>
<td> Average time spent during ICAP processing for successful requests. </td>
<td> MICROSECONDS </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> icap_stats.avg_error </td>
<td> Rate of all ICAP related errors. </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> icap_stats.avg_internal_error </td>
<td> Rate of internal errors when processing ICAP requests. </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> icap_stats.avg_modified </td>
<td> Rate of modified ICAP responses. </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> icap_stats.avg_passed </td>
<td> Rate of ICAP requests per second. </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> icap_stats.avg_requests </td>
<td> Rate of ICAP requests per second. </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> icap_stats.avg_server_error </td>
<td> Rate of ICAP server error responses. </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> icap_stats.avg_time_warning </td>
<td> Rate of requests taking time more than ICAP warning threshold. </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> icap_stats.avg_timedout </td>
<td> Rate of ICAP server error responses. </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> icap_stats.pct_blocked </td>
<td> Fraction of blocked ICAP responses. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> icap_stats.pct_error </td>
<td> Fraction of total ICAP errors. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> icap_stats.pct_internal_error </td>
<td> Fraction of requests failed due to internal errors. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> icap_stats.pct_modified </td>
<td> Fraction of modified ICAP responses. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> icap_stats.pct_passed </td>
<td> Fraction of allowed ICAP responses. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> icap_stats.pct_time_warning </td>
<td> Fraction of ICAP requests exceeding time warning threshold. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> icap_stats.pct_timedout </td>
<td> Fraction of ICAP requests timed out. </td>
<td> PERCENT </td>
<td> False </td>
<td>  </td>
<td> True </td>
</tr>
<tr>
<td> icap_stats.sum_blocked </td>
<td> Total blocked ICAP responses. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> icap_stats.sum_duration </td>
<td> Total time spent for ICAP processing by all ICAP requests. </td>
<td> MICROSECONDS </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> icap_stats.sum_error </td>
<td> Total ICAP related errors. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> icap_stats.sum_internal_error </td>
<td> Total internal error while processing ICAP requests. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> icap_stats.sum_modified </td>
<td> Total modified ICAP responses. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> icap_stats.sum_passed </td>
<td> Total allowed ICAP responses. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> icap_stats.sum_requests </td>
<td> Total ICAP requests. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> icap_stats.sum_server_error </td>
<td> Total error responses coming from ICAP server. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> icap_stats.sum_time_warning </td>
<td> Total requests exceeding time warning threshold. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> icap_stats.sum_timedout </td>
<td> Total timeouts for ICAP requests. </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Bot Metrics </h2>
<div class='container-fluid'>
<p>
Stats for Bot Detection Policy.
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> bot.avg_all_bots </td>
<td> Average number of requests which were classified as any BOT type (not HUMAN or UNKNOWN). </td>
<td> PER_SECOND </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> bot.avg_bad_bot </td>
<td> Averaged value of request per second which were classified as BAD_BOT. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.avg_bypassed </td>
<td> Averaged number of requests per second for which bot detection was bypassed via allow_list. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.avg_dangerous_bot </td>
<td> Averaged value of request per second which were classified as DANGEROUS_BOT. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.avg_evaluate_ip_location </td>
<td> Averaged number of requests per second for which IP network location was evaluated. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.avg_evaluate_ip_reputation </td>
<td> Averaged number of requests per second for which IP reputation was evaluated. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.avg_evaluate_user_agent </td>
<td> Averaged number of requests per second for which user agent was evaluated. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.avg_good_bot </td>
<td> Averaged value of requests per second which were classified as GOOD_BOT. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.avg_human </td>
<td> Averaged value of requests per second which were classified as HUMAN. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.avg_requests </td>
<td> Averaged number of requests per second which are executing the Bot Policy. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.avg_unknown </td>
<td> Averaged value of requests per second which were classified as UNKNOWN_CLIENT. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.avg_user_defined_bot </td>
<td> Averaged value of requests per second which were classified as USER_DEFINED_BOT. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.max_all_bots </td>
<td> Maximum value of requests per second which were classified as any BOT type (not HUMAN or UNKNOWN). </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> False </td>
</tr>
<tr>
<td> bot.max_bad_bot </td>
<td> Maximum value of request per second which were classified as BAD_BOT. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.max_bypassed </td>
<td> Maximum number of requests per second for which bot detection was bypassed via allow_list. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.max_dangerous_bot </td>
<td> Maximum value of requests per second which were classified as DANGEROUS_BOT. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.max_evaluate_ip_location </td>
<td> Maximum number of requests per second for which IP network location was evaluated. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.max_evaluate_ip_reputation </td>
<td> Maximum number of requests per second for which IP reputation was evaluated. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.max_evaluate_user_agent </td>
<td> Maximum number of requests per second for which user agent was evaluated. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.max_good_bot </td>
<td> Maximum value of requests per second which were classified as GOOD_BOT. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.max_human </td>
<td> Maximum value of requests per second which were classified as HUMAN. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.max_requests </td>
<td> Maximum number of requests per second which are executing the Bot Policy. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.max_unknown </td>
<td> Maximum value of requests per second which were classified as UNKNOWN_CLIENT. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.max_user_defined_bot </td>
<td> Maximum value of requests per second which were classified as USER_DEFINED_BOT. </td>
<td> PER_SECOND </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.sum_all_bots </td>
<td> Total number of requests which were classified as any BOT type (not HUMAN or UNKNOWN). </td>
<td> METRIC_COUNT </td>
<td> False </td>
<td>  </td>
<td> False </td>
</tr>
<tr>
<td> bot.sum_bad_bot </td>
<td> Total number of request which were classified as BAD_BOT. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.sum_bypassed </td>
<td> Total number of requests per second for which bot detection was bypassed via allow_list. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.sum_dangerous_bot </td>
<td> Total number of requests which were classified as DANGEROUS_BOT. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.sum_evaluate_ip_location </td>
<td> Total number of requests per second for which IP network location was evaluated. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.sum_evaluate_ip_reputation </td>
<td> Total number of requests per second for which IP reputation was evaluated. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.sum_evaluate_user_agent </td>
<td> Total number of requests per second for which user agent was evaluated. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.sum_good_bot </td>
<td> Total number of requests which were classified as GOOD_BOT. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.sum_human </td>
<td> Total number of requests which were classified as HUMAN. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.sum_requests </td>
<td> Total number of requests per second which are executing the Bot Policy. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.sum_unknown </td>
<td> Total number of requests which were classified as UNKNOWN_CLIENT. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> bot.sum_user_defined_bot </td>
<td> Total number of requests which were classified as USER_DEFINED_BOT. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Segroup_Stats Metrics </h2>
<div class='container-fluid'>
<p>
Stats for SE Group.
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> segroup_stats.avg_license_usage </td>
<td> Average license units used by SE's belonging to SeGroup. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> segroup_stats.max_license_usage </td>
<td> Maximum license units used by SE's belonging to SeGroup. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Envoy_Upstream_Stats Metrics </h2>
<div class='container-fluid'>
<p>
Envoy Upstream Metrics.
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> envoy_upstream_stats.avg_membership_healthy </td>
<td> Current cluster healthy total from upstream on controller Envoy. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> envoy_upstream_stats.avg_upstream_cx_active </td>
<td> Total active connections from upstream on controller Envoy. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> envoy_upstream_stats.avg_upstream_cx_rx_bytes_buffered </td>
<td> Received bytes currently buffered from upstream on controller Envoy. </td>
<td> BYTES </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> envoy_upstream_stats.avg_upstream_cx_tx_bytes_buffered </td>
<td> Sent bytes currently buffered from upstream on controller Envoy. </td>
<td> BYTES </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> envoy_upstream_stats.avg_upstream_rq_active </td>
<td> Total active requests from upstream on controller Envoy. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Envoy_Downstream_Stats Metrics </h2>
<div class='container-fluid'>
<p>
Envoy Downstream Metrics.
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> envoy_downstream_stats.avg_downstream_cx_active </td>
<td> Total active connections from downstream on controller Envoy. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> envoy_downstream_stats.avg_downstream_cx_rx_bytes_buffered </td>
<td> Received bytes currently buffered from downstream on controller Envoy. </td>
<td> BYTES </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> envoy_downstream_stats.avg_downstream_cx_tx_bytes_buffered </td>
<td> Sent bytes currently buffered from downstream on controller Envoy. </td>
<td> BYTES </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
<tr>
<td> envoy_downstream_stats.avg_downstream_rq_active </td>
<td> Total active requests from downstream on controller Envoy. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
</div>
<h2 class='text-primary'> Redis_Queue_Stats Metrics </h2>
<div class='container-fluid'>
<p>
Stats for task queue.
</p>
<table class='table table-bordered table-striped'>
<tr>
<th>Metric</th>
<th>Description</th>
<th>Units</th>
<th>Anomaly Detection</th>
<th>Anomaly Models</th>
<th>Priority</th>
</tr>
<tr>
<td> redis_queue_stats.max_size </td>
<td> Total count/size of each distinguished queue name. </td>
<td> METRIC_COUNT </td>
<td> True </td>
<td> EXPONENTIAL_WEIGHTED_MOVING_AVG </td>
<td> True </td>
</tr>
</table>
