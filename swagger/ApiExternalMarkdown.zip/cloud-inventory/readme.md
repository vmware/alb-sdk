<h2 class="text-primary">Inventory Query Options</h2>
<div class="container-fluid">
  <p>
    The following options can be passed as query parameters to the inventory API:
  </p>
  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>Option</th>
        <th>Description</th>
        <th>Defaults</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>include</td>
        <td>Filter for what type of information is returned per object. Eg. <code>include=config,metrics,alert</code></td>
        <td></td>
      </tr>
      <tr>
        <td>name</td>
        <td>Name of the object</td>
        <td></td>
      </tr>
      <tr>
        <td>page_size</td>
        <td>Number of objects to return per page</td>
        <td>25</td>
      </tr>
      <tr>
        <td>page</td>
        <td>Page to return</td>
        <td>1</td>
      </tr>
      <tr>
        <td>include_name</td>
        <td>Append <code>#&lt;name&gt;</code> to references</td>
        <td></td>
      </tr>
      <tr>
        <td>sort</td>
        <td>Parameter to sort results in ascending order. Eg. <code>sort=health_score</code></td>
        <td></td>
      </tr>
      <tr>
        <td>duration</td>
        <td>Duration window for alerts</td>
        <td></td>
      </tr>
      <tr>
        <td>start</td>
        <td>Start time for the metrics in ISO 8601 format. Default is UNIX Epoch. Eg. <code>start=1970-01-01T00:00:00</code></td>
        <td>1970-01-01T00:00:00</td>
      </tr>
      <tr>
        <td>stop</td>
        <td>End time for the metrics in ISO 8601 format. Default is now. Eg. <code>stop=2014-01-01T12:42:42</code></td>
        <td></td>
      </tr>
      <tr>
        <td>limit</td>
        <td>Max number of metric samples per metric requested. Eg. <code>limit=100</code> implies return only 100 samples</td>
        <td>60</td>
      </tr>
    </tbody>
  </table>
</div>
